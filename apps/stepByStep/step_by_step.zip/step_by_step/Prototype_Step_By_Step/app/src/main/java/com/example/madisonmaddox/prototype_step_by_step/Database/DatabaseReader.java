package com.example.madisonmaddox.prototype_step_by_step.Database;

/**
 * Created by acrimin on 11/28/2016.
 */

public class DatabaseReader {
}
