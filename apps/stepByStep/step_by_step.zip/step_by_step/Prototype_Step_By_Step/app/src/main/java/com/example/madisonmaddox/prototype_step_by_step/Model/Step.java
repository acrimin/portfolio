package com.example.madisonmaddox.prototype_step_by_step.Model;

import android.graphics.Bitmap;

import com.example.madisonmaddox.prototype_step_by_step.Database.ImageDownloader;

import java.util.concurrent.ExecutionException;

/**
 * Created by acrimin on 11/28/2016.
 */

public class Step {
    private int stepNum;
    private String stepInfo;
    private Bitmap image;

    public Step(int stepNum, String stepInfo, String imageFilename) {
        this.stepNum = stepNum;
        this.stepInfo = stepInfo;

        image = null;

        try {
            image = new ImageDownloader().execute(imageFilename).get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
    }

    public int getStepNum() {
        return stepNum;
    }

    public String getStepInfo() {
        return stepInfo;
    }

    public Bitmap getImageFilename() {
        return image;
    }


    @Override
    public String toString() {
        return "Step{" +
                "stepNum=" + stepNum +
                ", stepInfo='" + stepInfo + '\'' +
                '}';
    }
}
