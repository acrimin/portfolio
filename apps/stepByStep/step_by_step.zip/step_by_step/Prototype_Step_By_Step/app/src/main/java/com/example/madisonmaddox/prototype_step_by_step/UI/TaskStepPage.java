package com.example.madisonmaddox.prototype_step_by_step.UI;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.madisonmaddox.prototype_step_by_step.Database.DatabaseManager;
import com.example.madisonmaddox.prototype_step_by_step.Model.Step;
import com.example.madisonmaddox.prototype_step_by_step.R;

public class TaskStepPage extends Activity {

    Step[] steps;
    int stepNum = 0;
    TextView stepText;
    ImageView stepImage;
    Button nextButton;
    Button backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_step_page);

        stepText = (TextView) findViewById(R.id.stepText);
        stepImage = (ImageView) findViewById(R.id.stepImage);

        nextButton = (Button) findViewById(R.id.nextButton);
        backButton = (Button) findViewById(R.id.backButton);

        int taskId = getIntent().getIntExtra("taskId", -1);
        Toast.makeText(getApplicationContext(), "ID: " + taskId, Toast.LENGTH_LONG).show();

        steps = DatabaseManager.getInstance().getAllSteps(taskId);

        stepText.setText(steps[stepNum].getStepInfo());
        stepImage.setImageBitmap(steps[stepNum].getImageFilename());

        nameButtons();

    }

    public void imageClick(View view) {
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://youtu.be/dQw4w9WgXcQ")));
        Log.i("playing", "video");
    }

    public void readClick(View view) {

    }

    public void nextClick(View view) {
        if (stepNum < steps.length-1) {
            stepNum++;
        } else {
            goToMainPage();
        }

        nameButtons();

        stepText.setText(steps[stepNum].getStepInfo());
        stepImage.setImageBitmap(steps[stepNum].getImageFilename());
    }

    public void backClick(View view) {
        if (stepNum > 0) {
            stepNum--;
        } else {
            goToMainPage();
        }

        nameButtons();

        stepText.setText(steps[stepNum].getStepInfo());
        stepImage.setImageBitmap(steps[stepNum].getImageFilename());
    }

    private void nameButtons() {
        if (stepNum > 0) {
            backButton.setText("Back");
        } else {
            backButton.setText("Main Page");
        }

        if (stepNum < steps.length-1) {
            nextButton.setText("Next");
        } else {
            nextButton.setText("Finish");
        }
    }

    private void goToMainPage() {
        Intent nextScreen = new Intent(getApplicationContext(), MainPage.class);
        startActivity(nextScreen);
    }
}
