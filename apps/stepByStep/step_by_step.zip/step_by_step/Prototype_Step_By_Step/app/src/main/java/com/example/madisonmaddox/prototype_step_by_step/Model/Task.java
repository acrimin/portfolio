package com.example.madisonmaddox.prototype_step_by_step.Model;

import android.graphics.Bitmap;

import com.example.madisonmaddox.prototype_step_by_step.Database.DatabaseManager;
import com.example.madisonmaddox.prototype_step_by_step.Database.ImageDownloader;

import java.io.Serializable;
import java.util.concurrent.ExecutionException;

/**
 * Created by acrimin on 11/28/2016.
 */

public class Task implements Serializable {
    final int id;
    final String name;
    Bitmap image;

    public Task(int id, String name, String imageFilename) {
        this.id = id;
        this.name = name;

        // TODO change this to question image
        image = null;

        try {
            image = new ImageDownloader().execute(imageFilename).get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Bitmap getImage() {
        return image;
    }

    public Step[] getSteps() {
        return DatabaseManager.getInstance().getAllSteps(this);
    }

    @Override
    public String toString() {
        return "TaskPage{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }
}
