package com.example.madisonmaddox.prototype_step_by_step.UI;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import com.example.madisonmaddox.prototype_step_by_step.Database.DatabaseManager;
import com.example.madisonmaddox.prototype_step_by_step.Model.*;
import com.example.madisonmaddox.prototype_step_by_step.R;

import org.json.JSONException;

import java.util.concurrent.ExecutionException;

public class LoginActivity extends Activity {

    EditText textFieldLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        textFieldLogin = (EditText) findViewById(R.id.loginTextField);

        try {
            if (DatabaseManager.getInstance().init(getApplicationContext())) { // already logged in from previous
                nextScreen();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
    }
    }

    public void toSuggested(View view) {
        try {   // login
            Log.i("database", textFieldLogin.getText().toString());
            DatabaseManager.getInstance().login(textFieldLogin.getText().toString());
            Task[] tasks = DatabaseManager.getInstance().getAllTasks();
            Location[] locations = DatabaseManager.getInstance().getAllLocations();
            for (int i = 0; i < locations.length; i++) {
                Log.i("Database Results", locations[i].toString());
            }
            for (int i = 0; i < tasks.length; i++) {
                Log.i("Database Results", tasks[i].toString());
                Step[] steps = tasks[i].getSteps();
                for (int x = 0; x < steps.length; x++) {
                    Log.i("Database Results", steps[x].toString());
                }
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        nextScreen();
    }

    private void nextScreen() {
        Intent nextScreen = new Intent(getApplicationContext(), MainPage.class);
        startActivity(nextScreen);
    }


}
