package com.example.madisonmaddox.prototype_step_by_step.UI;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Toast;

import com.example.madisonmaddox.prototype_step_by_step.Database.DatabaseManager;
import com.example.madisonmaddox.prototype_step_by_step.Model.Task;
import com.example.madisonmaddox.prototype_step_by_step.R;

import java.util.ArrayList;

//import com.example.madisonmaddox.prototype_step_by_step.customAdapter;

public class MainPage extends AppCompatActivity {

    private ImageAdapter mAdapter;
    private GridView gridView;
    public Button button2;
    public Task[] tasks;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences("step_by_step", Context.MODE_PRIVATE);
        int user_id = sharedPreferences.getInt("user_id", 0);
        Toast.makeText(this, "user_id: " + user_id, Toast.LENGTH_LONG).show();

        // get tasks from database
        tasks = DatabaseManager.getInstance().getAllTasks();
        ArrayList<String> listTaskNames = new ArrayList<String>();
        ArrayList<Bitmap> listPics = new ArrayList<Bitmap>();
        for (int i = 0; i < tasks.length; i++) {
            listTaskNames.add(tasks[i].getName());
            listPics.add(tasks[i].getImage());
        }

        // prepared arraylist and passed it to the Adapter class
        mAdapter = new ImageAdapter(this, listTaskNames, listPics);

        // Set custom adapter to gridview
        gridView = (GridView) findViewById(R.id.gridview);
        gridView.setAdapter(mAdapter);

        // Implement On Item click listener
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int position,
                                    long arg3) {
                gotoTask(tasks[position]);
            }
        });
    }

    public void gotoTask(Task task) {
        Intent nextScreen = new Intent(getApplicationContext(), TaskStepPage.class);
        nextScreen.putExtra("taskId", task.getId());
        startActivity(nextScreen);
    }
}