<html>
<head>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js">"></script>

</head>
    <?php $id = $_GET['id']; ?>
<body>
<nav class="navbar navbar-default">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <a class="navbar-brand" href="https://people.cs.clemson.edu/~acrimin/step_by_step/" style="margin: -5 10 0 0;">
                <span><img style="height: 150%; margin: 0 5 0 0;" alt="Brand" src="/~acrimin/step_by_step/imgs/orange.png"></span> Step By Step
            </a>
        </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <li>
                    <a href="/~acrimin/step_by_step/user/user.php">User</a></li>
                <li class="active">
                    <a href="https://people.cs.clemson.edu/~acrimin/step_by_step/task/task_show.php">Task</a>
                </li>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>

    <div class="container">
    <h3>
  <span>Edit Task</span>
<form method="post" action="/~acrimin/step_by_step/task/task_edit.php?id=<?php echo $id?>">
  <button value="delete" name="delete" class='btn btn-danger pull-right'>Delete Task</button>
  </form>
</h3>

<?php
    require_once "../config.php";

    $error = "";
    if (isset($_POST['submit'])) {
       /* if (!empty($_POST['name']) && !empty($_POST['phone'])) {
            $name = $_POST['name'];
            $phone = $_POST['phone'];

            $sql = "UPDATE task SET 
                name = '$name', phone_number = '$phone'
                WHERE task_id = $id";

            if (mysqli_query($conn, $sql)) {
                header("Location: https://people.cs.clemson.edu/~acrimin/step_by_step/task/task_show.php");
            } else {
                $error = "Something Went Wrong";
            }
        } else {
            $error = "All Fields Must Be Filled";
        }
    */} else if (isset($_POST['cancel'])) {
        header("Location: https://people.cs.clemson.edu/~acrimin/step_by_step/task/task_show.php");
    } else if (isset($_POST['delete'])) {
        $sql = "DELETE FROM task WHERE task_id = $id";
            if (mysqli_query($conn, $sql)) {
                unlink("../imgs/task_cover_$id");
                header("Location: https://people.cs.clemson.edu/~acrimin/step_by_step/task/task_show.php");
            } else {
                $error = "Something Went Wrong";
            }
    }

    $sql = "SELECT 
            task_id, 
            name, 
            category,
            cover_image_filename
        FROM
            task 
        WHERE 
            task_id = $id";

    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_row($result);
    $name = $row[1];
    $category = $row[2];
    $image = $row[3];
?>

<img class='img-responsive' src='<?php echo $image; ?>'>

<form method="post" action="/~acrimin/step_by_step/task/task_edit.php?id=<?php echo $id?>">
  <div class="form-group row">
    <label for="name-input" class="col-2 col-form-label">Task Name</label>
    <div class="col-10">
    <input class="form-control" placeholder="Enter Task Name Here" value=<?php echo $name ?> type="text" name="name" id="name-input">
    </div>
  </div>
  <div class="form-group row">
    <label for="name-input" class="col-2 col-form-label">Category</label>
    <div class="col-10">
    <input class="form-control" placeholder="Enter Category" value=<?php echo "$category" ?> type="text" name="category" id="phone-input">
    </div>
  </div>
    <div class="form-group">
        <label for="fileInput">Cover Image File</label>
        <input type="file" name="fileToUpload"  class="form-control-file" id="fileInput" aria-describedby="fileHelp">
        <small id="fileHelp" class="form-text text-muted"></small>
    </div>
  <button type="submit" value="submit" name="submit" class="btn btn-primary">Update</button>
  <button type="cancel" value="cancel" name="cancel" class="btn btn-secondary">Cancel</button>
</form>
</div></body></html>

<?php if ($error != "") { ?>

<div class="alert alert-danger" role="alert">
    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
    <span class="sr-only">Error:</span>
    <?php echo $error; ?> 
</div> 

<?php } ?>
