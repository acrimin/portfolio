<html>
<head>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js">"></script>

</head>
<body>

<form method="post" action="/~acrimin/step_by_step/task/task_create.php" enctype="multipart/form-data">
    <table class="form-group table">
        <thead><th>Step Info</th><th>Step Image</th><th>Step Video</th><th></th>
        <tr>
        <td>
            <textarea class="form-control" id="step_text1" rows="3"></textarea>
        </td>
        <td>
            <input type="file" name="fileToUpload"  class="form-control-file" id="fileInput" aria-describedby="fileHelp">
        </td>
        <td>
            <input type="file" name="fileToUpload"  class="form-control-file" id="fileInput" aria-describedby="fileHelp">
        </td>
        <td>
            <button title='Add Row' type='button' class='btn btn-primary'>Add Step</button>
            <button title='Remove Row' type='button' class='btn btn-danger'>Remove Step</button>
        </td>
        </tr>
        <tr>
        <td>
            <textarea class="form-control" id="step_text1" rows="3"></textarea>
        </td>
        <td>
            <input type="file" name="fileToUpload"  class="form-control-file" id="fileInput" aria-describedby="fileHelp">
        </td>
        <td>
            <input type="file" name="fileToUpload"  class="form-control-file" id="fileInput" aria-describedby="fileHelp">
        </td>
        <td>
            <button title='Add Row' type='button' class='btn btn-primary'>Add Step</button>
            <button title='Remove Row' type='button' class='btn btn-danger'>Remove Step</button>
        </td>
        </tr>

    </table>
</form>
</div></body></html>

