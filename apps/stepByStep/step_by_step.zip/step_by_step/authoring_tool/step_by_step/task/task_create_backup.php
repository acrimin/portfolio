<html>
<head>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js">"></script>

</head>
<body>
<div class="container">
<h3>Create Task</h3>
<hr />

<?php
    $error = "";
    if (isset($_POST['submit'])) {
        if (!empty($_POST['name']) && !empty($_POST['category'])) {
            require_once "../config.php";

            $target_dir = "../imgs/";
            $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
            $imageFileType = pathinfo($target_file, PATHINFO_EXTENSION);
            $uploadOk = 1;
            
            // check if actual file
            $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
            if ($check == false) {
                $error = "File Is Not An Image";
            }


            // Check file size
            else if ($_FILES["fileToUpload"]["size"] > 500000) {
                $error = "Sorry, your file is too large.";
                $uploadOk = 0;
            }

            // Allow certain file formats
            else if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
                $error = "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                $uploadOk = 0;
            }

            else if ($uploadOk == 1) {
                $name = $_POST['name'];
                $category = $_POST['category'];

                $sql = "INSERT INTO task 
                    (name, category)
                    VALUES ('$name', '$category')";

                mysqli_query($conn, $sql);
                $id = mysqli_insert_id($conn);
                
                $target_file = "imgs/task_cover_$id.$imageFileType";
                $real_target_file = "https://people.cs.clemson.edu/~acrimin/step_by_step/" . $target_file;
                $local_target_file = "../" . $target_file;

                $sql = "UPDATE task SET
                    cover_image_filename = '$real_target_file' 
                    WHERE task_id = $id";

                if (!move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], 
                        $local_target_file)) {
                    $error = "Error Uploading File.";
                }
                chmod("$local_target_file", 644);
                if (mysqli_query($conn, $sql)) {
                    header("Location: https://people.cs.clemson.edu/~acrimin/step_by_step/task/task_show.php");
                } else {
                    $error = "Something Went Wrong";
                }
            }
        } else {
            $error = "All Fields Must Be Filled";
        }
    }
    if (isset($_POST['cancel'])) {
        header("Location: https://people.cs.clemson.edu/~acrimin/step_by_step/task/task_show.php");
    }
?>

<form method="post" action="/~acrimin/step_by_step/task/task_create.php" enctype="multipart/form-data">
  <div class="form-group row">
    <label for="name-input" class="col-2 col-form-label">Task Name</label>
    <div class="col-10">
    <input class="form-control" placeholder="Enter Task Name" type="text" name="name" id="name-input">
    </div>
  </div>
  <div class="form-group row">
    <label for="name-input" class="col-2 col-form-label">Category</label>
    <div class="col-10">
    <input class="form-control" placeholder="Enter Category" type="text" name="category" id="name-input">
    </div>
    </div>

    <div class="form-group">
        <label for="fileInput">Cover Image File</label>
        <input type="file" name="fileToUpload"  class="form-control-file" id="fileInput" aria-describedby="fileHelp">
        <small id="fileHelp" class="form-text text-muted"></small>
    </div>

    <table class="form-group table">
        <thead><th>Step Info</th><th>Step Image</th><th>Step Video</th><th></th>
        <tr>
        <td>
            <textarea class="form-control" id="step_text1" rows="3"></textarea>
        </td>
        <td>
            <input type="file" name="fileToUpload"  class="form-control-file" id="fileInput" aria-describedby="fileHelp">
        </td>
        <td>
            <input type="file" name="fileToUpload"  class="form-control-file" id="fileInput" aria-describedby="fileHelp">
        </td>
        <td>
            <button title='Add Row' type='button' class='btn btn-primary'>Add Step</button>
            <button title='Remove Row' type='button' class='btn btn-danger'>Remove Step</button>
        </td>
        </tr>
        <tr>
        <td>
            <textarea class="form-control" id="step_text1" rows="3"></textarea>
        </td>
        <td>
            <input type="file" name="fileToUpload"  class="form-control-file" id="fileInput" aria-describedby="fileHelp">
        </td>
        <td>
            <input type="file" name="fileToUpload"  class="form-control-file" id="fileInput" aria-describedby="fileHelp">
        </td>
        <td>
            <button title='Add Row' type='button' class='btn btn-primary'>Add Step</button>
            <button title='Remove Row' type='button' class='btn btn-danger'>Remove Step</button>
        </td>
        </tr>

    </table>

  <button type="submit" value="submit" name="submit" class="btn btn-primary">Submit</button>
  <button type="cancel" value="cancel" name="cancel" class="btn btn-secondary">Cancel</button>
</form>
</div></body></html>

<?php if ($error != "") { ?>

<div class="alert alert-danger" role="alert">
    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
    <span class="sr-only">Error:</span>
    <?php echo $error; ?> 
</div> 

<?php } ?>
