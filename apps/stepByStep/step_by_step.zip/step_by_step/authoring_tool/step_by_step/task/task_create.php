<html>
<head>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js">"></script>
    <script src="/~acrimin/step_by_step/task/task_create.js"></script>
</head>
<nav class="navbar navbar-default">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <a class="navbar-brand" href="https://people.cs.clemson.edu/~acrimin/step_by_step/" style="margin: -5 10 0 0;">
                <span><img style="height: 150%; margin: 0 5 0 0;" alt="Brand" src="/~acrimin/step_by_step/imgs/orange.png"></span> Step By Step
            </a>
        </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <li>
                    <a href="/~acrimin/step_by_step/user/user.php">User</a></li>
                <li class="active">
                    <a href="https://people.cs.clemson.edu/~acrimin/step_by_step/task/task_show.php">Task</a>
                </li>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>

<body>
<div class="container">
<h3>Create Task</h3>
<hr />

<?php
    function uploadFile($f, $name) {
        $target_dir = "../imgs/";
        $target_file = $target_dir . basename($f["name"]);
        $imageFileType = pathinfo($target_file, PATHINFO_EXTENSION);

        // check if actual file
        $check = getimagesize($f["tmp_name"]);
        if ($check == false) {
            return array(FALSE, "File Is Not An Image");
        }

        // Check file size
        else if ($f["size"] > 500000) {
            return array(FALSE, "Sorry, your file is too large.");
        }
        
        $target_file = "imgs/$name.$imageFileType";
        $real_target_file = "https://people.cs.clemson.edu/~acrimin/step_by_step/" . $target_file;
        $local_target_file = "../" . $target_file;

        if (!move_uploaded_file($f["tmp_name"], $local_target_file)) {
            return array(FALSE, "Error Uploading File.");
        }
        chmod("$local_target_file", 644);

        return array(TRUE, $real_target_file);
    }

    function deleteAll($id) {
        return;
    }
    
    $error = "";
    if (isset($_POST['submit'])) {
        if (empty($_POST['name']) || empty($_POST['category'])) {
            $error = "All Fields Must Be Filled";
            goto end;
        }
        
        // insert steps
        $i = 0;
        $step_text = $_POST['step_text'];
        if (count($_FILES['step_image']['name']) != count($step_text)) {
            $error = "All Steps Must Be filled";    
            goto end;
        }

        require_once "../config.php";

        $name = $_POST['name'];
        $category = $_POST['category'];

        $sql = "INSERT INTO task 
            (name, category)
            VALUES ('$name', '$category')";

        mysqli_query($conn, $sql);
        $id = mysqli_insert_id($conn);

        $fileInfo = uploadFile($_FILES["task_image"], "task_cover_$id");

        if ($fileInfo[0] != TRUE) {
            $error = $fileInfo[1];
            deleteAll($id);
            goto end;
        }

        $sql = "UPDATE task SET
            cover_image_filename = '$fileInfo[1]' 
            WHERE task_id = $id";

        if (!mysqli_query($conn, $sql)) {
            $error = "Something Went Wrong";
            deleteAll($id);
            goto end;
        }

        $step_file = array();
        $sql = "INSERT INTO task_steps
            (task_id, step_num, step_info, image_filename)
            VALUES ";
        for ($i = 0; $i < count($step_text); $i++) {
            if ($i != 0)
                $sql = $sql . ", ";
            $text = $step_text[$i];
            $step_file["name"] = $_FILES['step_image']['name'][$i];
            $step_file['tmp_name'] = $_FILES['step_image']['tmp_name'][$i];
            $step_file['size'] = $_FILES['step_image']['size'][$i];
            $tail = $i . "_" . $id;
            $fileInfo = uploadFile($step_file, "step_image_$tail");

            if ($fileInfo[0] != TRUE) {
                $error = $fileInfo[1];
                deleteAll($id);
                goto end;
            }
            $sql = $sql . "($id, $i, '$text', '$fileInfo[1]')";
        }

        if (!mysqli_query($conn, $sql)) {
            $error = "Something Went Wrong";
            deleteAll($id);
            goto end;
        }

        header("Location: https://people.cs.clemson.edu/~acrimin/step_by_step/task/task_show.php");
    }

    else if (isset($_POST['cancel'])) {
        header("Location: https://people.cs.clemson.edu/~acrimin/step_by_step/task/task_show.php");
    }
    end:
?>

<form method="post" action="/~acrimin/step_by_step/task/task_create.php" enctype="multipart/form-data" runat="server">
  <div class="form-group row">
    <label for="name-input" class="col-2 col-form-label">Task Name</label>
    <div class="col-10">
    <input class="form-control" placeholder="Enter Task Name" type="text" name="name" id="name-input">
    </div>
  </div>
  <div class="form-group row">
    <label for="name-input" class="col-2 col-form-label">Category</label>
    <div class="col-10">
    <input class="form-control" placeholder="Enter Category" type="text" name="category" id="name-input">
    </div>
    </div>

    <div class="form-group">
        <label for="fileInput">Cover Image File</label>
        <input type="file" name="task_image"  class="form-control-file" id="fileInput" aria-describedby="fileHelp">
        <small id="fileHelp" class="form-text text-muted"></small>
    </div>

    <table class="form-group table">
        <thead><th>Step Info</th><th>Step Image</th><th></th>
        <tr id="step_0">
            <td>
                <textarea name=step_text[] class="form-control" rows="3"></textarea>
            </td>
            <td>
                <input type="file" name="step_image[]" class="form-control-file">
            </td>
            <td>
                <button title='Add Row' type='button' onclick="insert(0);" class='btn btn-primary'>
                    <span class="glyphicon glyphicon-plus" aria-hidden="true"></span>
                </button>
                <button title='Remove Row' type='button' onclick="remove(0);" class='btn btn-danger'>
                    <span class="glyphicon glyphicon-minus" aria-hidden="true"></span>
                </button>
            </td>
        </tr>
    </table>

  <button type="submit" value="submit" name="submit" class="btn btn-primary">Submit</button>
  <button type="cancel" value="cancel" name="cancel" class="btn btn-secondary">Cancel</button>
</form>
</div></body></html>

<?php if ($error != "") { ?>

<div class="alert alert-danger" role="alert">
    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
    <span class="sr-only">Error:</span>
    <?php echo $error; ?> 
</div> 

<?php } ?>

