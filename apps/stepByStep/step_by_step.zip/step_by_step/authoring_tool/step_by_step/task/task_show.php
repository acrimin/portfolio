<html>
<head>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js">"></script>
</head>
   
<body>
<nav class="navbar navbar-default">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <a class="navbar-brand" href="https://people.cs.clemson.edu/~acrimin/step_by_step/" style="margin: -5 10 0 0;">
                <span><img style="height: 150%; margin: 0 5 0 0;" alt="Brand" src="/~acrimin/step_by_step/imgs/orange.png"></span> Step By Step
            </a>
        </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <li>
                    <a href="/~acrimin/step_by_step/user/user.php">User</a></li>
                <li class="active">
                    <a href="https://people.cs.clemson.edu/~acrimin/step_by_step/task/task_show.php">Task</a>
                </li>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>

    <div class="container">
    <h3>
  <span>Tasks</span>
  <a href=https://people.cs.clemson.edu/~acrimin/step_by_step/task/task_create.php><button class='btn btn-primary pull-right'>Create Task</button></a>
</h3>
<hr/>
    <table class="table table-bordred table-striped" id="taskTable">
    
    <thead>
        <th>Image</th>
        <th>Name</th>
        <th>Category</th>
        <th>Edit</th>
    </thead>
	
<?php
    require_once "../config.php";
    $sql = "
        SELECT
	    task_id,
	    name,
        category,
        cover_image_filename
        FROM 
	    task 
	    ORDER BY name";
    
    $result = mysqli_query($conn, $sql);

    while ($row = mysqli_fetch_row($result)) {
        $id = $row[0];
        $name = $row[1];
        $category = $row[2];
        $image = $row[3];
        echo "<tr><td><img class='img-responsive' style='max-height: 50;' src='$image'></td>";
        echo "<td>$name</td><td>$category</td>";
        echo "<td><a href=https://people.cs.clemson.edu/~acrimin/step_by_step/task/task_edit.php?id=$id>
            <button type='button' class='btn btn-primary'><span class='glyphicon glyphicon-pencil'></span></button>
	</td>";
        echo "</tr>";
    } 
?>

</table></div></body></html>
