rowIndex = 1;
function insert(row) {
    console.log("insert: " + row);
    var target = document.getElementById("step_" + row);
    var row = document.createElement('tr');
    row.setAttribute("id", "step_" + rowIndex);

    var td = document.createElement('td');
    var textarea = document.createElement('textarea');
        textarea.setAttribute("name","step_text[]");
        textarea.setAttribute("class","form-control");
        textarea.setAttribute("rows","3");
    td.appendChild(textarea);
    row.appendChild(td);

    td = document.createElement('td');
    var input = document.createElement('input');
        input.setAttribute("type", "file");
        input.setAttribute("name", "step_image[]");
        input.setAttribute("class", "form-control-file");
    td.appendChild(input);
    row.appendChild(td);

    td = document.createElement('td');
    var buttonAdd = document.createElement('button');
        buttonAdd.setAttribute("title", "Add Row");
        buttonAdd.setAttribute("type", "button");
        buttonAdd.setAttribute("onclick", "insert(" + rowIndex + ");");
        buttonAdd.setAttribute("class", "btn btn-primary");
        var span = document.createElement('span');
            span.setAttribute("class", "glyphicon glyphicon-plus");
            span.setAttribute("aria-hidden", "TRUE");
        buttonAdd.appendChild(span);
    td.appendChild(buttonAdd);

    var buttonRemove = document.createElement('button');
        buttonRemove.setAttribute("title", "Remove Row");
        buttonRemove.setAttribute("type", "button");
        buttonRemove.setAttribute("onclick", "remove(" + rowIndex + ");");
        buttonRemove.setAttribute("class", "btn btn-danger");
        var span = document.createElement('span');
            span.setAttribute("class", "glyphicon glyphicon-minus");
            span.setAttribute("aria-hidden", "TRUE");
        buttonRemove.appendChild(span);
    td.appendChild(buttonRemove);
    row.appendChild(td);
    
    rowIndex++;

    target.parentNode.insertBefore(row, target.nextSibling); 
    return row;
}

function remove(row) {
    if (row == 0) 
        return;
    console.log("remove: " + row);
    var elem = document.getElementById("step_" + row);
    return elem.parentNode.removeChild(elem);
}
