<?php
    require_once "config.php";

    $user_id = $_GET['user_id'];
    $updated = $_GET['updated'];

    $sql = "
        SELECT 
            task.task_id, 
            task_video.video_filename, 
            task_video.thumbnail_filename 
        FROM 
            user, 
            user_task, 
            task, 
            task_video 
        WHERE 
            user.user_id = '$user_id' AND 
            user_task.user_id = '$user_id' AND 
            user_task.task_id = task.task_id AND 
            task_video.task_id = task.task_id AND 
            task.updated > $updated";

    $result = mysqli_query($conn, $sql);

    $json = array();
    while ($row = mysqli_fetch_row($result)) {
        $step = array();
        $step['task_id'] = $row[0];
        $step['video_filename']  = $row[1];
        $step['thumbnail_filename']  = $row[2];
        array_push($json, $step);
    } 

    echo json_encode($json);
?>
