rowIndex = 1;
function insert(row) {
    console.log("insert: " + row);
    var target = document.getElementById("row_" + row);
    row = target.cloneNode(true);
    
    row.id = "row_" + rowIndex;

    var btns = row.lastChild.previousSibling.childNodes;
    console.log(btns[1]);
    console.log(btns[3]);
    btns[1].setAttribute("onclick", "insert(" + rowIndex + ");");
    btns[3].setAttribute("onclick", "remove(" + rowIndex + ");");

    rowIndex++
    target.parentNode.insertBefore(row, target.nextSibling); 
    return row;
}

function remove(row) {
    if (row == 0) 
        return;
    console.log("remove: " + row);
    var elem = document.getElementById("row_" + row);
    return elem.parentNode.removeChild(elem);
}
