<html>
<head>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js">"></script>

</head>
<body>
<nav class="navbar navbar-default">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <a class="navbar-brand" href="https://people.cs.clemson.edu/~acrimin/step_by_step/" style="margin: -5 10 0 0;">
                <span><img style="height: 150%; margin: 0 5 0 0;" alt="Brand" src="/~acrimin/step_by_step/imgs/orange.png"></span> Step By Step
            </a>
        </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <li class="active">
                    <a href="/~acrimin/step_by_step/user/user.php">User<span class="sr-only">(current)</span></a></li>
                <li>
                    <a href="https://people.cs.clemson.edu/~acrimin/step_by_step/task/task_show.php">Task</a>
                </li>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>

<div class="container">
<h3>Create User: Account</h3>
<hr />

<?php
    $error = "";
    if (isset($_POST['submit'])) {
        if (empty($_POST['name']) || empty($_POST['phone'])) {
            $error = "All Fields Must be Filled";
            goto end;
        }

        require_once "../config.php";

        $name = $_POST['name'];
        $phone = $_POST['phone'];

        $sql = "INSERT INTO user 
            (name, phone_number)
            VALUES 
            ('$name', '$phone')";

        if (!mysqli_query($conn, $sql)) {
            $error = "Something Went Wrong";
            goto end;
        }

        $id = mysqli_insert_id($conn);

        header("Location: https://people.cs.clemson.edu/~acrimin/step_by_step/user/user_location_create.php?id=$id&name=$name");
    }

    else if (isset($_POST['cancel'])) {
        header("Location: https://people.cs.clemson.edu/~acrimin/step_by_step/user/user.php");
    }
    end:
?>

<form method="post" action="">
  <div class="form-group row">
    <label for="name-input" class="col-2 col-form-label">Name</label>
    <div class="col-10">
    <input class="form-control" placeholder="Enter Name" type="text" name="name" id="name-input">
    </div>
  </div>
  <div class="form-group row">
    <label for="name-input" class="col-2 col-form-label">Phone Number</label>
    <div class="col-10">
    <input class="form-control" placeholder="Enter Phone Number" type="text" name="phone" id="name-input">
    </div>
  </div>

  <button type="submit" value="submit" name="submit" class="btn btn-primary">Next</button>
  <button type="cancel" value="cancel" name="cancel" class="btn btn-secondary">Cancel</button>
</form>
</div>

<?php 
    if ($error != "") {
?> 
<div class="alert alert-danger" role="alert">
    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
    <span class="sr-only">Error:</span>
    <?php echo $error; ?> 
</div> 

<?php } ?>
</body></html>
