<html>
<head>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="user.js"></script>
</head>



<body>
<nav class="navbar navbar-default">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <a class="navbar-brand" href="https://people.cs.clemson.edu/~acrimin/step_by_step/" style="margin: -5 10 0 0;">
                <span><img style="height: 150%; margin: 0 5 0 0;" alt="Brand" src="/~acrimin/step_by_step/imgs/orange.png"></span> Step By Step
            </a>
        </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <li class="active">
                    <a href="/~acrimin/step_by_step/user/user.php">User<span class="sr-only">(current)</span></a></li>
                <li>
                    <a href="https://people.cs.clemson.edu/~acrimin/step_by_step/task/task_show.php">Task</a>
                </li>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>

<div class="container">
<h3><b>Create User:</b> Locations</h3>
<h4><b>Name:</b> <?php echo $_GET['name']; ?></h4>
<hr />

<?php
    $id = $_GET['id'];
    $error = "";
    if (isset($_POST['submit'])) {
        require_once "../config.php";

        $names = $_POST['name'];
        $lats = $_POST['lat'];
        $lons = $_POST['lon'];

        if (count($names) != count($lats) || count($names) != count($lons)) {
            $error = "All Fields Must Be Filled";
            goto end;
        }

        $sql = "INSERT INTO location 
            (user_id, name, latitude, longitude)
            VALUES "; 
        for ($i = 0; $i < count($names); $i++) {
            if ($i != 0)
                $sql = $sql . ", ";
            $name = $names[$i];
            $lat = $lats[$i];
            $lon = $lons[$i];

            $sql = $sql . "($id, '$name',$lat, $lon)";
        }
        
        $result = mysqli_query($conn, $sql);
        if (!$result) {
            $error = "Something Went Wrong";
            $error = $error . "<br>$result";
            goto end; }

        $name = $_GET['name'];
        header("Location: https://people.cs.clemson.edu/~acrimin/step_by_step/user/user_task_create.php?id=$id&name=$name");
    }

    else if (isset($_POST['cancel'])) {
        header("Location: https://people.cs.clemson.edu/~acrimin/step_by_step/user/user.php");
    }
    end:
?>

<p><h4><b>Instructions:</b></h4>
<ol>
    <li>Go to <a href=http://www.latlong.net>latlong.net</a></li>
    <li>Enter place name and click find</li>
    <li>Copy latitude and longitude into respective fields</li>
</ol>

<form method="post" action="">
    <table class="form-group table">
        <thead><th>Location Name</th><th>Latitude</th><th>Longitude</th><th></th>
        <tr id="row_0">
            <td>
                <input class="form-control" placeholder="Enter Location Name" type="text" name="name[]">
            </td>
            <td>
                <input class="form-control" placeholder="Enter Latitude" type="text" name="lat[]">
            </td>
            <td>
                <input class="form-control" placeholder="Enter Longitude" type="text" name="lon[]">
            </td>
            <td>
                <button title='Add Row' type='button' onclick="insert(0);" class='btn btn-primary'>
                    <span class="glyphicon glyphicon-plus" aria-hidden="true"></span>
                </button>
                <button title='Remove Row' type='button' onclick="remove(0);" class='btn btn-danger'>
                    <span class="glyphicon glyphicon-minus" aria-hidden="true"></span>
                </button>
            </td>
        </tr>
    </table>

  <button type="submit" value="submit" name="submit" class="btn btn-primary">Next</button>
  <button type="cancel" value="cancel" name="cancel" class="btn btn-secondary">Cancel</button>
</form>
</div>

<?php 
    if ($error != "") {
?> 
<div class="alert alert-danger" role="alert">
    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
    <span class="sr-only">Error:</span>
    <?php echo $error; ?> 
</div> 

<?php } ?>
</body></html>

