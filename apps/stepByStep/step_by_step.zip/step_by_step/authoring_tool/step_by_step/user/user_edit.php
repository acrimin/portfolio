<html>
<head>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js">"></script>

</head>
    <?php $id = $_GET['id']; ?>
<body>
<nav class="navbar navbar-default">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <a class="navbar-brand" href="https://people.cs.clemson.edu/~acrimin/step_by_step/" style="margin: -5 10 0 0;">
                <span><img style="height: 150%; margin: 0 5 0 0;" alt="Brand" src="/~acrimin/step_by_step/imgs/orange.png"></span> Step By Step
            </a>
        </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <li class="active">
                    <a href="/~acrimin/step_by_step/user/user.php">User</a></li>
                <li>
                    <a href="https://people.cs.clemson.edu/~acrimin/step_by_step/task/task_show.php">Task</a>
                </li>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>

    <div class="container">
    <h3>
  <span>Edit User</span>
<form method="post" action="/~acrimin/step_by_step/user/user_edit.php?id=<?php echo $id?>">
  <button value="delete" name="delete" class='btn btn-danger pull-right'>Delete User</button>
  </form>
</h3>

<?php
    require_once "../config.php";

    $error = 0;
    if (isset($_POST['submit'])) {
        if (!empty($_POST['name']) && !empty($_POST['phone'])) {
            $name = $_POST['name'];
            $phone = $_POST['phone'];

            $sql = "UPDATE user SET 
                name = '$name', phone_number = '$phone'
                WHERE user_id = $id";

            if (mysqli_query($conn, $sql)) {
                header("Location: https://people.cs.clemson.edu/~acrimin/step_by_step/user/user_show.php");
            } else {
                $error = 2;
            }
        } else {
            $error = 1;
        }
    } else if (isset($_POST['cancel'])) {
        header("Location: https://people.cs.clemson.edu/~acrimin/step_by_step/user/user_show.php");
    } else if (isset($_POST['delete'])) {
        $sql = "DELETE FROM user WHERE user_id = $id";
            if (mysqli_query($conn, $sql)) {
                header("Location: https://people.cs.clemson.edu/~acrimin/step_by_step/user/user_show.php");
            } else {
                $error = 2;
            }
    }

    $sql = "SELECT 
            user_id, 
            name, 
            phone_number
        FROM
            user
        WHERE 
            user_id = $id";

    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_row($result);
    $name = $row[1];
    $phone = $row[2];
?>

<form method="post" action="/~acrimin/step_by_step/user/user_edit.php?id=<?php echo $id?>">
  <div class="form-group row">
    <label for="name-input" class="col-2 col-form-label">Name</label>
    <div class="col-10">
    <input class="form-control" placeholder="Enter Name Here" value=<?php echo $name ?> type="text" name="name" id="name-input">
    </div>
  </div>
  <div class="form-group row">
    <label for="name-input" class="col-2 col-form-label">Phone Number</label>
    <div class="col-10">
    <input class="form-control" placeholder="Enter Phone Number" value=<?php echo "$phone" ?> type="text" name="phone" id="phone-input">
    </div>
  </div>

  <button type="submit" value="submit" name="submit" class="btn btn-primary">Update</button>
  <button type="cancel" value="cancel" name="cancel" class="btn btn-secondary">Cancel</button>
</form>
</div></body></html>

<?php 
    if ($error == 1) {
?> 
<div class="alert alert-danger" role="alert">
    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
    <span class="sr-only">Error:</span>
    All Fields Must Be Filled
</div> 

<?php 
} else if ($error == 2) {
?>

<div class="alert alert-danger" role="alert">
    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
    <span class="sr-only">Error:</span>
    Something Went Wrong
</div> 

<?php } ?>
