<html>
<head>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js">"></script>
</head>
   
<body>
<nav class="navbar navbar-default">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <a class="navbar-brand" href="https://people.cs.clemson.edu/~acrimin/step_by_step/" style="margin: -5 10 0 0;">
                <span><img style="height: 150%; margin: 0 5 0 0;" alt="Brand" src="/~acrimin/step_by_step/imgs/orange.png"></span> Step By Step
            </a>
        </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <li class="active">
                    <a href="/~acrimin/step_by_step/user/user.php">User<span class="sr-only">(current)</span></a></li>
                <li>
                    <a href="https://people.cs.clemson.edu/~acrimin/step_by_step/task/task_show.php">Task</a>
                </li>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>

    <div class="container">
    <h3>
  <span>Users</span>
  <a href=https://people.cs.clemson.edu/~acrimin/step_by_step/user/user_account_create.php><button class='btn btn-primary pull-right'>Create User</button></a>
</h3>
<hr/>
    <table class="table table-bordred table-striped" id="userTable">
    
    <thead>
        <th>Name</th>
        <th>Phone Number</th>
        <th>Edit</th>
    </thead>
	
<?php
    require_once "../config.php";
    $sql = "
        SELECT
	    user_id,
	    name,
	    phone_number 
        FROM 
	    user
	    ORDER BY name";
    
    $result = mysqli_query($conn, $sql);

    while ($row = mysqli_fetch_row($result)) {
        $id = $row[0];
        $name = $row[1];
        $phone_number = $row[2];
        echo "<tr><td>$name</td><td>$phone_number</td>";
        echo "<td><a href=https://people.cs.clemson.edu/~acrimin/step_by_step/user/user_show.php?id=$id>
            <button type='button' class='btn btn-primary'><span class='glyphicon glyphicon-pencil'></span></button>
	</td>";
        echo "</tr>";
    } 
?>

</table></div></body></html>
