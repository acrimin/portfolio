<html>
<head>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js">"></script>
    <script src="user.js"></script>
</head>
<body>
<nav class="navbar navbar-default">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <a class="navbar-brand" href="https://people.cs.clemson.edu/~acrimin/step_by_step/" style="margin: -5 10 0 0;">
                <span><img style="height: 150%; margin: 0 5 0 0;" alt="Brand" src="/~acrimin/step_by_step/imgs/orange.png"></span> Step By Step
            </a>
        </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <li class="active">
                    <a href="/~acrimin/step_by_step/user/user.php">User<span class="sr-only">(current)</span></a></li>
                <li>
                    <a href="https://people.cs.clemson.edu/~acrimin/step_by_step/task/task_show.php">Task</a>
                </li>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>
<div class="container">
<h3>Create User: Tasks</h3>
<h4><b>Name:</b> <?php echo $_GET['name']; ?></h4>
<hr />

<?php
    $id = $_GET['id'];
    $error = "";

    require_once "../config.php";

    $sql = "SELECT task_id, name FROM task";
    $result = mysqli_query($conn, $sql);
    $task = array();
    while ($row = mysqli_fetch_row($result)) {
        $task[$row[1]] = $row[0];
    }
    
    ksort($task);

    $sql = "SELECT location_id, name FROM location WHERE user_id = $id";
    $result = mysqli_query($conn, $sql);
    $location = array();
    while ($row = mysqli_fetch_row($result)) {
        $location[$row[1]] = $row[0];
    }
    
    ksort($location);

    if (isset($_POST['submit'])) {
        $tasks = $_POST['task'];
        $locations = $_POST['location'];

        $sql = "INSERT INTO user_task 
            (user_id, task_id, location_id)
            VALUES "; 
        for ($i = 0; $i < count($tasks); $i++) {
            if ($i != 0)
                $sql = $sql . ", ";
            $task = $tasks[$i];
            $location = $locations[$i];

            $sql = $sql . "($id, $task, $location)";
        }

        echo "$sql";

        if (!mysqli_query($conn, $sql)) {
            $error = "Something Went Wrong";
            goto end;
        }

        header("Location: https://people.cs.clemson.edu/~acrimin/step_by_step/user/user.php");
    }

    else if (isset($_POST['cancel'])) {
        header("Location: https://people.cs.clemson.edu/~acrimin/step_by_step/user/user.php");
    }
    end:
?>

<form method="post" action="">
    <table class="form-group table">
        <thead><th>Task</th><th>Location</th><th></th>
        <tr id="row_0">
            <td>
                <select name="task[]" id="task_dropdown" class="form-control">
                    <?php
                    foreach ($task as $task_name => $task_id) {
                        echo "<option value='$task_id'>$task_name</option>";
                    }
                    ?>
                </select>
            </td>
            <td>
                <select name="location[]" id="location_dropdown" class="form-control">
                    <?php
                    foreach ($location as $location_name => $location_id) {
                        echo "<option value='$location_id'>$location_name</option>";
                    }
                    ?>
                </select>
            </td>
            <td>
                <button title='Add Row' type='button' onclick="insert(0);" class='btn btn-primary'>
                    <span class="glyphicon glyphicon-plus" aria-hidden="true"></span>
                </button>
                <button title='Remove Row' type='button' onclick="remove(0);" class='btn btn-danger'>
                    <span class="glyphicon glyphicon-minus" aria-hidden="true"></span>
                </button>
            </td>
        </tr>
    </table>

  <button type="submit" value="submit" name="submit" class="btn btn-primary">Next</button>
  <button type="cancel" value="cancel" name="cancel" class="btn btn-secondary">Cancel</button>
</form>
</div></body></html>

<?php 
    if ($error != "") {
?> 
<div class="alert alert-danger" role="alert">
    <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
    <span class="sr-only">Error:</span>
    <?php echo $error; ?> 
</div> 

<?php } ?>
