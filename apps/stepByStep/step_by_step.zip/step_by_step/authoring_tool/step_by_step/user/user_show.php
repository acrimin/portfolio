<html>
<head>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js">"></script>

</head>
<body>
<div class="container">
<nav class="navbar">
  <div class="navbar-header">
    <h3><b>User:</b> <?php echo $_GET['name']; ?></h3>
    <h5><b>Phone Number:</b> 5922839949</h5>
   </div>
     <form method="post" action="user_delete.php?<?php echo "id=".$_GET['id']."&name=".$_GET['name']; ?>">
       <button style="margin-top: 20px" class="btn btn-danger navbar-btn pull-right">Delete User</button>
     </form>
</nav>
<hr />
<?php
    if (isset($_POST['submit'])) {
        header("Location: https://people.cs.clemson.edu/~acrimin/step_by_step/user/user.php");
    }
?>

<h4 style="margin-left: 50px"><b>Location Info: </b>
<form method="post" action"">
    <button style="margin-right: 50px" type="submit" value="submit" name="submit" class="btn btn-primary pull-right">
        <span class='glyphicon glyphicon-pencil'></span>
    </button>
</form>

<table class="table">
   <thead><th>Location Name</th><th>Latitude</th><th>Longitude</th></thead> 
    <?php 
        $sql = "SELECT name, latitude, longitude";   
    ?>
</table>

<br><br>

<h4 style="margin-left: 50px"><b>Task Info: </b>
<form method="post" action"">
    <button style="margin-right: 50px" type="submit" value="submit" name="submit" class="btn btn-primary pull-right">
        <span class='glyphicon glyphicon-pencil'></span>
    </button>
</form>

<table class="table">
   <thead><th>Task Name</th><th>Location Name</th></thead> 
</table>

<br><br>

<form method="post" action="">
  <button type="submit" value="submit" name="submit" class="btn btn-primary">Save</button>
</form>

</body></html>
