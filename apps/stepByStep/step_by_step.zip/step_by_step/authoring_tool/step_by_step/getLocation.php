<?php
    require_once "config.php";

    $user_id = $_GET['user_id'];

    $sql = "SELECT * FROM location WHERE user_id = '$user_id'";
    $result = mysqli_query($conn, $sql);

    $json = array();
    while ($row = mysqli_fetch_row($result)) {
        $location = array();
        $location['location_id'] = $row[0];
        $location['name']  = $row[2];
        $location['latitude'] = $row[3];
        $location['longitude'] = $row[4];
        array_push($json, $location);
    } 

    echo json_encode($json);
?>
