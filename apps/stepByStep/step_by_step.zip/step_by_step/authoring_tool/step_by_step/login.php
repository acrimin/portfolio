<?php
    require_once "config.php";
    
    $phone_number = $_GET['phone'];
    
    $sql = "SELECT * FROM user WHERE phone_number ='$phone_number' LIMIT 1";
    $result = mysqli_query($conn, $sql);
    
    $json = array();
    while ($row = mysqli_fetch_row($result)) {
        $userData = array();
        $userData['user_id'] = $row[0];
        $userData['name']  = $row[1];
        $userData['phone_number'] = $row[2];
        array_push($json, $userData);
    }   

    echo json_encode($json);
?>
