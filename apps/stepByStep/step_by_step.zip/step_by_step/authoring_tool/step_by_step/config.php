<?php
    $DB_USER = 'StpByStp_b2v5';
    $DB_PASSWORD = 'password12345';
    $DB_SERVER = 'mysql1.cs.clemson.edu';
    $DB_NAME = 'Step-By-Step_yvx6';

    $conn = mysqli_connect($DB_SERVER, $DB_USER, $DB_PASSWORD, $DB_NAME);

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
?>
