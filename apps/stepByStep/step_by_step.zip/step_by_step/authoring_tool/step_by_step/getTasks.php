<?php
    require_once "config.php";

    $user_id = $_GET['user_id'];
    $updated = $_GET['updated'];

    $sql = "
        SELECT 
            task.task_id, 
            user_task.location_id, 
            task.name, 
            task.category,
            task.cover_image_filename,
            task.updated 
        FROM 
            user, 
            user_task, 
            task 
        WHERE 
            user.user_id = '$user_id' AND 
            user_task.user_id = '$user_id' AND 
            user_task.task_id = task.task_id AND 
            task.updated > '$updated'";

    $result = mysqli_query($conn, $sql);

    $json = array();
    while ($row = mysqli_fetch_row($result)) {
        $task = array();
        $task['task_id'] = $row[0];
        $task['location_id']  = $row[1];
        $task['name'] = $row[2];
        $task['category'] = $row[3];
        $task['cover_image_filename'] = $row[4];
        $task['updated'] = $row[5];
        array_push($json, $task);
    } 

    echo json_encode($json);


?>
