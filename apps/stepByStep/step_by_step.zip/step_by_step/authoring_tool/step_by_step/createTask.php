
<?php
    require_once "config.php";

    $name = $_GET['name'];
    $category = $_GET['phone_number'];

    $sql = "INSERT INTO task 
            (name, category)
        VALUES 
            ('$name', '$category')";

    if (mysqli_query($conn, $sql)) {
        echo "Successfully"; 
?>
