<?php
    require_once "config.php";

    $user_id = $_GET['user_id'];
    $updated = $_GET['updated'];

    $sql = "
        SELECT 
            task.task_id, 
            task_steps.step_num, 
            task_steps.step_info,
            task_steps.image_filename 
        FROM 
            user, 
            user_task, 
            task, 
            task_steps 
        WHERE 
            user.user_id = '$user_id' AND 
            user_task.user_id = '$user_id' AND 
            user_task.task_id = task.task_id AND 
            task_steps.task_id = task.task_id AND 
            task.updated > '$updated'";
    
    $result = mysqli_query($conn, $sql);

    $json = array();
    while ($row = mysqli_fetch_row($result)) {
        $step = array();
        $step['task_id'] = $row[0];
        $step['step_num']  = $row[1];
        $step['step_info'] = $row[2];
        $step['image_filename'] = $row[3];
        array_push($json, $step);
    } 

    echo json_encode($json);
?>
