package ui;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

import java.awt.Dimension;
import java.awt.FlowLayout;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JList;
import java.awt.Insets;
import javax.swing.JLabel;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import javax.swing.border.EtchedBorder;
import javax.swing.SwingConstants;
import javax.swing.event.ListSelectionListener;

import model.Album;
import model.SettingsAccess;
import model.User;

import javax.swing.event.ListSelectionEvent;
import java.awt.BorderLayout;
import java.awt.ComponentOrientation;
import java.awt.Component;
import javax.swing.Box;

/**
 * Displays and manages the SettingsScreen ui. Should updates settings class on save.
 */
@SuppressWarnings("serial")
public class SettingScreen extends JFrame {
	private JTextField textField;
	private JTextField textField_3;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_4;
	
	private User[] users;
	
	private JTextField textField_5;
	
	private SettingsAccess settingsAccess;
	
	public SettingScreen() {
		settingsAccess = new SettingsAccess();
		populateUsers();
		
		
		getContentPane().setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));
		
		TitledBorder setURL;
		setURL = BorderFactory.createTitledBorder("Server URL");
		JPanel urlPanel = new JPanel();
		urlPanel.setPreferredSize(new Dimension(getContentPane().getWidth(), 50));
		urlPanel.setBorder(setURL);
		getContentPane().add(urlPanel);
		
		textField = new JTextField();
		textField.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				textField.setFocusable(true);
				textField.requestFocusInWindow();
			}
		});
		textField.setText(settingsAccess.getSettings().getServerURL());
		textField.setPreferredSize(new Dimension(450,20));
		textField.setFocusable(false);
		urlPanel.add(textField);
		
		TitledBorder userProfiles;
		userProfiles = BorderFactory.createTitledBorder("User Profiles");
		JPanel profilePanel = new JPanel();
		profilePanel.setPreferredSize(new Dimension(500,250));
		profilePanel.setBorder(userProfiles);
		getContentPane().add(profilePanel);
		profilePanel.setLayout(new BoxLayout(profilePanel, BoxLayout.X_AXIS));
		
		JPanel userPanel = new JPanel();
		profilePanel.add(userPanel);
		userPanel.setLayout(new BorderLayout(0, 0));
		
		final JList<User> profileList = new JList<User>(users);
		profileList.setFocusable(false);
		userPanel.add(profileList, BorderLayout.CENTER);
		profileList.setSelectionBackground(new Color(0,170,170));
		
		JPanel addRemovePanel = new JPanel();
		addRemovePanel.setAlignmentX(Component.RIGHT_ALIGNMENT);
		addRemovePanel.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
		userPanel.add(addRemovePanel, BorderLayout.SOUTH);
		addRemovePanel.setLayout(new BoxLayout(addRemovePanel, BoxLayout.LINE_AXIS));
		
		
		JButton buttonPlus = new JButton("+");
		buttonPlus.setFocusable(false);
		buttonPlus.setMinimumSize(new Dimension(50, 25));
		buttonPlus.setMaximumSize(new Dimension(50, 25));
		buttonPlus.setPreferredSize(new Dimension(50, 25));
		buttonPlus.setFocusPainted(false);
		addRemovePanel.add(buttonPlus);
		buttonPlus.setMargin(new Insets(0, 0, 0, 0));
		
		JButton buttonMinus = new JButton("-");
		buttonMinus.setPreferredSize(new Dimension(50, 25));
		buttonMinus.setMinimumSize(new Dimension(50, 25));
		buttonMinus.setMaximumSize(new Dimension(50, 25));
		buttonMinus.setFocusable(false);
		buttonMinus.setFocusPainted(false);
		addRemovePanel.add(buttonMinus);
		buttonMinus.setMargin(new Insets(0, 0, 0, 0));
		profileList.addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent e) {
				int i = profileList.getSelectedIndex();
				textField_1.setText(users[i].getName());
				textField_2.setText(users[i].getPIN());
				textField_3.setText(users[i].isAdminString());
				textField_4.setText(String.valueOf(users[i].getRestrictLevel()));
			}
		});
		
		Component horizontalStrut = Box.createHorizontalStrut(20);
		horizontalStrut.setPreferredSize(new Dimension(10, 0));
		horizontalStrut.setMinimumSize(new Dimension(10, 0));
		horizontalStrut.setMaximumSize(new Dimension(10, 32767));
		profilePanel.add(horizontalStrut);
		
		JPanel infoPanel = new JPanel();
		profilePanel.add(infoPanel);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[]{72, 130, 0};
		gbl_panel.rowHeights = new int[]{26, 26, 16, 0, 0, 0};
		gbl_panel.columnWeights = new double[]{0.0, 1.0, Double.MIN_VALUE};
		gbl_panel.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		infoPanel.setLayout(gbl_panel);
		
		JLabel lblName = new JLabel("Name:");
		GridBagConstraints gbc_lblName = new GridBagConstraints();
		gbc_lblName.anchor = GridBagConstraints.EAST;
		gbc_lblName.insets = new Insets(0, 0, 5, 5);
		gbc_lblName.gridx = 0;
		gbc_lblName.gridy = 0;
		infoPanel.add(lblName, gbc_lblName);
		
		textField_1 = new JTextField();
		GridBagConstraints gbc_textField_1 = new GridBagConstraints();
		gbc_textField_1.insets = new Insets(0, 0, 5, 0);
		gbc_textField_1.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField_1.gridx = 1;
		gbc_textField_1.gridy = 0;
		infoPanel.add(textField_1, gbc_textField_1);
		textField_1.setColumns(10);
		
		JLabel lblPin = new JLabel("PIN: ");
		GridBagConstraints gbc_lblPin = new GridBagConstraints();
		gbc_lblPin.anchor = GridBagConstraints.EAST;
		gbc_lblPin.insets = new Insets(0, 0, 5, 5);
		gbc_lblPin.gridx = 0;
		gbc_lblPin.gridy = 1;
		infoPanel.add(lblPin, gbc_lblPin);
		
		textField_2 = new JTextField();
		GridBagConstraints gbc_textField_2 = new GridBagConstraints();
		gbc_textField_2.insets = new Insets(0, 0, 5, 0);
		gbc_textField_2.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField_2.gridx = 1;
		gbc_textField_2.gridy = 1;
		infoPanel.add(textField_2, gbc_textField_2);
		textField_2.setColumns(10);
		
		JLabel lblUserType = new JLabel("User Type:");
		GridBagConstraints gbc_lblUserType = new GridBagConstraints();
		gbc_lblUserType.anchor = GridBagConstraints.NORTHEAST;
		gbc_lblUserType.insets = new Insets(0, 0, 5, 5);
		gbc_lblUserType.gridx = 0;
		gbc_lblUserType.gridy = 2;
		infoPanel.add(lblUserType, gbc_lblUserType);
		
		textField_3 = new JTextField();
		GridBagConstraints gbc_textField_3 = new GridBagConstraints();
		gbc_textField_3.insets = new Insets(0, 0, 5, 0);
		gbc_textField_3.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField_3.gridx = 1;
		gbc_textField_3.gridy = 2;
		infoPanel.add(textField_3, gbc_textField_3);
		textField_3.setColumns(10);
		
		JLabel lblRestrictionLevel = new JLabel("Restriction Level:");
		GridBagConstraints gbc_lblRestrictionLevel = new GridBagConstraints();
		gbc_lblRestrictionLevel.anchor = GridBagConstraints.EAST;
		gbc_lblRestrictionLevel.insets = new Insets(0, 0, 5, 5);
		gbc_lblRestrictionLevel.gridx = 0;
		gbc_lblRestrictionLevel.gridy = 3;
		infoPanel.add(lblRestrictionLevel, gbc_lblRestrictionLevel);
		
		textField_4 = new JTextField();
		GridBagConstraints gbc_textField_4 = new GridBagConstraints();
		gbc_textField_4.insets = new Insets(0, 0, 5, 0);
		gbc_textField_4.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField_4.gridx = 1;
		gbc_textField_4.gridy = 3;
		infoPanel.add(textField_4, gbc_textField_4);
		textField_4.setColumns(10);
		
		JLabel lblFavorites = new JLabel("Favorites:");
		GridBagConstraints gbc_lblFavorites = new GridBagConstraints();
		gbc_lblFavorites.anchor = GridBagConstraints.EAST;
		gbc_lblFavorites.insets = new Insets(0, 0, 0, 5);
		gbc_lblFavorites.gridx = 0;
		gbc_lblFavorites.gridy = 4;
		infoPanel.add(lblFavorites, gbc_lblFavorites);
		
		JButton btnBrowse = new JButton("Browse");
		btnBrowse.setFocusPainted(false);
		btnBrowse.setFocusable(false);
		GridBagConstraints gbc_btnBrowse = new GridBagConstraints();
		gbc_btnBrowse.anchor = GridBagConstraints.WEST;
		gbc_btnBrowse.gridx = 1;
		gbc_btnBrowse.gridy = 4;
		infoPanel.add(btnBrowse, gbc_btnBrowse);
		
		Component horizontalStrut_1 = Box.createHorizontalStrut(20);
		horizontalStrut_1.setPreferredSize(new Dimension(10, 0));
		horizontalStrut_1.setMinimumSize(new Dimension(10, 0));
		horizontalStrut_1.setMaximumSize(new Dimension(10, 32767));
		profilePanel.add(horizontalStrut_1);
		
		TitledBorder approvedAlbums;
		approvedAlbums = BorderFactory.createTitledBorder("Approved Albums by Restriction Level");
		JPanel restrictedPanel = new JPanel();
		restrictedPanel.setPreferredSize(new Dimension(500, 200));
		restrictedPanel.setBorder(approvedAlbums);
		getContentPane().add(restrictedPanel);
		restrictedPanel.setLayout(new BorderLayout(0, 0));
		
		JPanel restrictionValuePanel = new JPanel();
		restrictionValuePanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		restrictionValuePanel.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		restrictedPanel.add(restrictionValuePanel, BorderLayout.NORTH);
		restrictionValuePanel.setLayout(new FlowLayout(FlowLayout.LEFT, 5, 5));
		
		JLabel lblRestrictionLevels = new JLabel("Restriction Levels:");
		restrictionValuePanel.add(lblRestrictionLevels);
		
		textField_5 = new JTextField();
		restrictionValuePanel.add(textField_5);
		textField_5.setHorizontalAlignment(SwingConstants.RIGHT);
		textField_5.setEditable(false);
		textField_5.setText("3");
		textField_5.setColumns(10);
		
		JPanel albumListPanel = new JPanel();
		restrictedPanel.add(albumListPanel);
		GridBagLayout gbl_panel1 = new GridBagLayout();
		gbl_panel1.columnWidths = new int[]{120, 10 ,120,10, 120};
		gbl_panel1.rowHeights = new int[]{16, 103, 0};
		gbl_panel1.columnWeights = new double[]{0.0, 0.0};
		gbl_panel1.rowWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
		albumListPanel.setLayout(gbl_panel1);
		
		JLabel lblLevel = new JLabel("Level 1:");
		GridBagConstraints gbc_lblLevel = new GridBagConstraints();
		gbc_lblLevel.anchor = GridBagConstraints.CENTER;
		gbc_lblLevel.insets = new Insets(0, 0, 5, 0);
		gbc_lblLevel.gridx = 0;
		gbc_lblLevel.gridy = 0;
		albumListPanel.add(lblLevel, gbc_lblLevel);
		
		JList<Album> list = new JList<Album>(settingsAccess.getSettings().getApprovedAlbums(1));
		list.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		list.setSelectionBackground(new Color(0,170,170));
		GridBagConstraints gbc_list = new GridBagConstraints();
		gbc_list.fill = GridBagConstraints.BOTH;
		gbc_list.gridx = 0;
		gbc_list.gridy = 1;
		albumListPanel.add(list, gbc_list);
		
		JLabel lblLevel2 = new JLabel("Level 2:");
		GridBagConstraints gbc_lblLevel2 = new GridBagConstraints();
		gbc_lblLevel2.anchor = GridBagConstraints.CENTER;
		gbc_lblLevel2.insets = new Insets(0, 0, 5, 0);
		gbc_lblLevel2.gridx = 2;
		gbc_lblLevel2.gridy = 0;
		albumListPanel.add(lblLevel2, gbc_lblLevel2);
		
		JList<Album> albumlist2 = new JList<Album>(settingsAccess.getSettings().getApprovedAlbums(2));
		albumlist2.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		albumlist2.setSelectionBackground(new Color(0,170,170));
		GridBagConstraints gbc_alist2 = new GridBagConstraints();
		gbc_alist2.fill = GridBagConstraints.BOTH;
		gbc_alist2.gridx = 2;
		gbc_alist2.gridy = 1;
		albumListPanel.add(albumlist2, gbc_alist2);
		
		JLabel lblLevel3 = new JLabel("Level 3:");
		GridBagConstraints gbc_lblLevel3 = new GridBagConstraints();
		gbc_lblLevel3.anchor = GridBagConstraints.CENTER;
		gbc_lblLevel3.insets = new Insets(0, 0, 5, 0);
		gbc_lblLevel3.gridx = 4;
		gbc_lblLevel3.gridy = 0;
		albumListPanel.add(lblLevel3, gbc_lblLevel3);
		
		JList<Album> albumlist3 = new JList<Album>(settingsAccess.getSettings().getApprovedAlbums(3));
		albumlist3.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		albumlist3.setSelectionBackground(new Color(0,170,170));
		GridBagConstraints gbc_alist3 = new GridBagConstraints();
		gbc_alist3.fill = GridBagConstraints.BOTH;
		gbc_alist3.gridx = 4;
		gbc_alist3.gridy = 1;
		albumListPanel.add(albumlist3, gbc_alist3);
		
		
		JPanel saveCancel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		saveCancel.setPreferredSize(new Dimension(500,30));
		
		getContentPane().add(saveCancel);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SettingScreen.super.dispose();
			}
		});
		saveCancel.add(btnCancel);
		
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SettingScreen.super.dispose();
			}
		});
		btnSave.setForeground(Color.WHITE);
		btnSave.setSelected(true);
		getRootPane().setDefaultButton(btnSave);
		saveCancel.add(btnSave);
		
		pack();
	}

	private void populateUsers() {
		users = new User[settingsAccess.getSettings().getUserCount()];
		for (int i = 0; i < users.length; i++) {
			users[i] = settingsAccess.getSettings().getUser(i);
		}
	}
}
