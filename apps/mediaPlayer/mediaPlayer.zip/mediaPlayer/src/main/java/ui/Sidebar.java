package ui;

import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLabel;

import java.awt.Component;
import javax.swing.JList;
import javax.swing.Box;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;

import java.awt.Color;
import javax.swing.border.LineBorder;

import java.awt.Dimension;
import javax.swing.ListSelectionModel;
import java.awt.Font;
import javax.swing.event.ListSelectionListener;

import javax.swing.event.ListSelectionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;
import javax.swing.BoxLayout;

/**
 * Displays and manages the sidebar ui. updates music table depending on tab chosen.
 */
@SuppressWarnings("serial")
public class Sidebar extends JPanel {
	private JTextField txtSearch;
	private final Color BACKGROUNDCOLOR = new Color(210,210,210);
	
	private final ImageIcon whiteHeartOutIcon = new ImageIcon(System.getProperty("user.dir") + "/res/whiteHeartOut.png");
	private final ImageIcon pinkHeartOutIcon = new ImageIcon(System.getProperty("user.dir") + "/res/pinkHeartOut.png");
	private final ImageIcon whiteHeartFillIcon = new ImageIcon(System.getProperty("user.dir") + "/res/whiteHeartFill.png");
	private final ImageIcon pinkHeartFillIcon = new ImageIcon(System.getProperty("user.dir") + "/res/pinkHeartFill.png");

	JLabel lblHeart;
	JLabel lblFavoriteThisSong;
	JPanel pnlFavorite;
	
	private int selectedIndex;
	private JList<String> list;
	private MainScreen mainScreen;

	public Sidebar(MainScreen mainScreen) {
		this.mainScreen = mainScreen;
		
		setMinimumSize(new Dimension(220, 10));
		setMaximumSize(new Dimension(220, 32767));	
		setPreferredSize(new Dimension(220, 10));
		setBackground(BACKGROUNDCOLOR);
		setLayout(new BorderLayout(0, 0));
		
		Component verticalStrut = Box.createVerticalStrut(10);
		add(verticalStrut, BorderLayout.SOUTH);
		
		Component verticalStrut_1 = Box.createVerticalStrut(20);
		add(verticalStrut_1, BorderLayout.NORTH);
		
		Component horizontalStrut = Box.createHorizontalStrut(10);
		add(horizontalStrut, BorderLayout.WEST);
		
		Component horizontalStrut_1 = Box.createHorizontalStrut(10);
		add(horizontalStrut_1, BorderLayout.EAST);
		
		JPanel panel = new JPanel();
		panel.setBackground(BACKGROUNDCOLOR);
		add(panel, BorderLayout.CENTER);
		panel.setLayout(new BorderLayout(0, 0));
		
		txtSearch = new JTextField();
		txtSearch.setPreferredSize(new Dimension(15, 33));
		txtSearch.setBorder(new LineBorder(new Color(0, 170, 170), 3));
		txtSearch.setText("Search");
		panel.add(txtSearch, BorderLayout.NORTH);
		txtSearch.setColumns(10);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(BACKGROUNDCOLOR);
		panel.add(panel_1, BorderLayout.SOUTH);
		panel_1.setLayout(new BorderLayout(0, 0));
		
		ImageIcon settingsIcon = new ImageIcon(System.getProperty("user.dir") + "/res/settings.png");
		ImageIcon settingsPressedIcon = new ImageIcon(System.getProperty("user.dir") + "/res/settingsPressed.png");
		JButton btnSettings = new JButton(settingsIcon);
		btnSettings.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				settingsClicked();
			}
		});
		
		pnlFavorite = new JPanel();
		pnlFavorite.setVisible(false);
		pnlFavorite.setLayout(new BoxLayout(pnlFavorite, BoxLayout.X_AXIS));
		pnlFavorite.setOpaque(false);
		
		MouseFavoriteAdapter mouseFavorite = new MouseFavoriteAdapter();
		lblHeart = new JLabel(whiteHeartOutIcon);
		lblHeart.addMouseListener(mouseFavorite);
		pnlFavorite.add(lblHeart);
		
		Component horizStrutFavorite = Box.createHorizontalStrut(10);
		pnlFavorite.add(horizStrutFavorite);
		
		lblFavoriteThisSong = new JLabel("Favorite Album");
		lblFavoriteThisSong.setForeground(Color.WHITE);
		lblFavoriteThisSong.addMouseListener(mouseFavorite);
		pnlFavorite.add(lblFavoriteThisSong);
		panel_1.add(pnlFavorite, BorderLayout.WEST);

		
		btnSettings.setPreferredSize(new Dimension(40, 40));
		btnSettings.setMaximumSize(new Dimension(40, 20));
		btnSettings.setBorderPainted(false);
		btnSettings.setBorder(null);
		btnSettings.setPressedIcon(settingsPressedIcon);
		btnSettings.setFocusPainted(false);
		btnSettings.setContentAreaFilled(false);
		panel_1.add(btnSettings, BorderLayout.EAST);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(BACKGROUNDCOLOR);
		panel.add(panel_2, BorderLayout.CENTER);
		panel_2.setLayout(new BorderLayout(0, 0));
		
		DefaultListModel<String> listModel = new DefaultListModel<String>();
		listModel.addElement("Favorites");
		listModel.addElement("Library");
		
		list = new JList<String>(listModel);
		list.setFocusable(false);
		list.setSelectedIndex(0);
		selectedIndex = 0;
		list.addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent arg0) {
				if (list.getSelectedIndex() == -1) {
					list.setSelectedIndex(selectedIndex);
				}
				else {
					selectedIndex = list.getSelectedIndex();
					changeList(list.getSelectedIndex());
				}				
			}
		});
		list.setFixedCellHeight(40);
		list.setFont(new Font("Tahoma", Font.PLAIN, 16));
		list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		list.setSelectionBackground(Color.GRAY);
		list.setBackground(BACKGROUNDCOLOR);
		panel_2.add(list);
		
		Component verticalStrut_2 = Box.createVerticalStrut(20);
		panel_2.add(verticalStrut_2, BorderLayout.NORTH);
		
		Component verticalStrut_3 = Box.createVerticalStrut(20);
		panel_2.add(verticalStrut_3, BorderLayout.SOUTH);
		
	}
	
	private void changeList(int index) {
		pnlFavorite.setVisible(false);
		if (index == 0) {
			mainScreen.getMusicTable().setFavoriteAlbumList();
		}
		else if (index == 1) {
			mainScreen.getMusicTable().setServerAlbumList();
		}					
	}

	public void setTrackView() {
		if (list.getSelectedIndex() == 0) {
			ListSelectionListener listener = list.getListSelectionListeners()[0];
			list.removeListSelectionListener(listener);
			list.removeSelectionInterval(0, 2);	
			selectedIndex = -1;
			list.addListSelectionListener(listener);
			
			lblHeart.setIcon(whiteHeartFillIcon);
			lblFavoriteThisSong.setText("Unfavorite Album");
			
			pnlFavorite.setVisible(true);
		} else {		// not favorites
			
		}
	}

	private void settingsClicked() {
		SettingScreen frame = new SettingScreen();
		frame.setTitle("Settings");
		frame.setVisible(true);
	}
	
	private class MouseFavoriteAdapter extends MouseAdapter {
		boolean isFavorite;
		@Override
		public void mousePressed(MouseEvent arg0) {
			lblFavoriteThisSong.setForeground(new Color(255,0,171));
			isFavorite = (lblHeart.getIcon().equals(whiteHeartFillIcon));
			if (isFavorite) {
				lblHeart.setIcon(pinkHeartFillIcon);
			} else {
				lblHeart.setIcon(pinkHeartOutIcon);
			}				
		}

		@Override
		public void mouseReleased(MouseEvent arg0) {
			lblFavoriteThisSong.setForeground(new Color(255,255,255));
			if (isFavorite) {
				lblHeart.setIcon(whiteHeartOutIcon);
				lblFavoriteThisSong.setText("Favorite Album");
			} else {
				lblHeart.setIcon(whiteHeartFillIcon);
				lblFavoriteThisSong.setText("Unfavorite Album");
			}
		}
		
		@Override
		public void mouseClicked(MouseEvent arg0) {
			if (isFavorite) {	// remove from favorites
				mainScreen.getCurrentUser().removeAlbumFromFavorites(mainScreen.getMusicTable().getCurrentAlbum());
				list.setSelectedIndex(0);
			} else {			// add to favorites
			}

		}
	}
	
}
