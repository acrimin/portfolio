package ui;

import javax.swing.JPanel;
import java.awt.Dimension;
import java.awt.BorderLayout;
import javax.swing.ImageIcon;

import java.awt.Color;
import javax.swing.JLayeredPane;
import javax.swing.JLabel;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * Displays and manages the SeekBar ui
 */
@SuppressWarnings("serial")
public class SeekBar extends JLayeredPane {
	JPanel fullPanel;
	JPanel elapsedPanel;
	JPanel marker;
	double locationPercent = 0.0;
	
	private int maxValue = 100;
	private int value = 0;
	private ImageIcon markerIcon;
	private ImageIcon pressedMarkerIcon;
	private JLabel iconLabel;

	public SeekBar() {
		addComponentListener(new ComponentAdapter() {
			@Override
			public void componentResized(ComponentEvent arg0) {
				changeSize();
			}
		});

		setMinimumSize(new Dimension(10, 15));
		setMaximumSize(new Dimension(32767, 15));
		setPreferredSize(new Dimension(645, 15));
		
		fullPanel = new JPanel();
		fullPanel.setBounds(0, 6, this.getWidth(), 3);
		fullPanel.setBackground(Color.WHITE);
		
		elapsedPanel = new JPanel();
		elapsedPanel.setBounds(0, 6, 300, 3);
		elapsedPanel.setBackground(Color.GRAY);
		
		marker = new JPanel();
		marker.setBounds(-7, 0, 15, 15);
		marker.setLayout(new BorderLayout());
		marker.setOpaque(false);
		
		markerIcon = new ImageIcon(System.getProperty("user.dir") + "/res/circle.png");
		pressedMarkerIcon = new ImageIcon(System.getProperty("user.dir") + "/res/circlePressed.png");
		iconLabel = new JLabel(markerIcon);
		marker.add(iconLabel, BorderLayout.CENTER);
		
		add(fullPanel, new Integer(1));
		add(elapsedPanel, new Integer(2));
		add(marker, new Integer(3));
		
		addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				iconLabel.setIcon(pressedMarkerIcon);
			}
			@Override
			public void mouseReleased(MouseEvent e) {
				iconLabel.setIcon(markerIcon);
			}
		});	
		
		disable();
	}
	
	private void changeSize() {
		fullPanel.setBounds(0, 6, this.getWidth(), 3);
		elapsedPanel.setBounds(0, 6, (int) (this.getWidth() * locationPercent), 3);
		marker.setBounds((int) (this.getWidth() * locationPercent) - 7, 0, 15, 15);
	}
	
	public JPanel getMarker() {
		return marker;
	}
	
	public void setMaxValue(int value) {
		maxValue = value;
	}
	
	public long getMaxValue() {
		return maxValue;
	}
	
	public void setValue(int value) {
		this.value = value;
		locationPercent = ((double) value)/maxValue;
		this.changeSize();
	}
	
	public int setLocation(int value) {
		if (value < 0) 
			value = 0;
		else if (value > this.getWidth()) {
			value = this.getWidth();
		}
		locationPercent = ((double) value) / this.getWidth();
		this.value = (int) (locationPercent * getMaxValue());
		this.changeSize();
		
		return this.value;
	}
	
	public int getValue() {
		return value;
	}
	
	public void enable() {
		elapsedPanel.setVisible(true);
		iconLabel.setVisible(true);
	}
	
	public void disable() {
		elapsedPanel.setVisible(false);
		iconLabel.setVisible(false);
	}
}
