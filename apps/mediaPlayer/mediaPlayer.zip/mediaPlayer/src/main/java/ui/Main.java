package ui;

import javax.swing.JFrame;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import model.Settings;
import model.SettingsAccess;

/**
 * Starts the authentication screen of the application and sets up settings. 
 * Runs with system look and feel
 */
public class Main {


	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException
				| UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		SettingsAccess sa = new SettingsAccess();
		sa.updateSettings(new Settings());
		
		AuthScreen frame = new AuthScreen();
		frame.setTitle("Login Required");
//		frame.setSize(500,200);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
