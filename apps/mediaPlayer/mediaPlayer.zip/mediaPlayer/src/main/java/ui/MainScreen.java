package ui;

import javax.swing.JFrame;
import java.awt.BorderLayout;
import javax.swing.BoxLayout;
import javax.swing.JPanel;

import model.User;

import java.awt.Color;

/**
 * Runs the main screen window. This class calls the MusicTable, 
 * PlayerControls, and Sidebar classes to display different aspects of the ui. 
 * This class acts as the access point between those three classes to communicate the ui.
 */
@SuppressWarnings("serial")
public class MainScreen extends JFrame {
	private MusicTable musicTable;
	private Sidebar sidebar;
	private PlayerControls playerControls;	
	private User currentUser;
	
	public MainScreen(User user) {
		currentUser = user;	
		
		setBackground(Color.WHITE);
		getContentPane().setBackground(Color.WHITE);
		getContentPane().setLayout(new BorderLayout(0, 0));
		
		playerControls = new PlayerControls(this);
		getContentPane().add(playerControls, BorderLayout.SOUTH);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
		
		sidebar = new Sidebar(this);
		panel.add(sidebar);
		
		musicTable = new MusicTable(this);
		musicTable.setBorder(null);
		panel.add(musicTable);		
	}

	public MusicTable getMusicTable() {
		return musicTable;
	}

	public Sidebar getSidebar() {
		return sidebar;
	}

	public PlayerControls getPlayerControls() {
		return playerControls;
	}
	
	public User getCurrentUser() {
		return currentUser;
	}
	

}
