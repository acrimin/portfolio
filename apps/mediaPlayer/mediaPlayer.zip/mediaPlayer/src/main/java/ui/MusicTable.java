package ui;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import model.Album;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.ListSelectionModel;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * Displays and manages the MusicTable ui.
 */
@SuppressWarnings("serial")
public class MusicTable extends JPanel {
	final Color HIGHLIGHTCOLOR = new Color(0,150,150);
	final Color HOVERCOLOR = new Color(50 ,200, 200);
	
	private JTable table;
	private DefaultTableModel albumData;
	private DefaultTableModel trackData;
	boolean albumView;
	private Album currentAlbum;

	private MainScreen mainScreen;

	public MusicTable(MainScreen mainScreen) {
		this.mainScreen = mainScreen;
		
		setBorder(null);
		setBackground(Color.WHITE);
		setLayout(new BorderLayout(0, 0));
		
		table = new JTable() {
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		TableMouseListener mouseListener = new TableMouseListener();
		table.addMouseListener(mouseListener);
		table.addMouseMotionListener(mouseListener);
		table.setBorder(null);
		table.setForeground(new Color(0, 0, 0));
		table.setFocusable(false);
		table.setSelectionBackground(HOVERCOLOR);
		table.setIntercellSpacing(new Dimension(0, 1));
		table.setFillsViewportHeight(true);
		table.setFont(new Font("Tahoma", Font.PLAIN, 15));
		table.setAutoCreateRowSorter(true);
		table.setRowMargin(0);
		table.setRowHeight(30);
		table.setSelectionForeground(Color.WHITE);
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setShowVerticalLines(false);
		table.setShowGrid(false);
		table.setShowHorizontalLines(false);
		setFavoriteAlbumList();
		
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setViewportBorder(null);
		scrollPane.setBorder(null);
		scrollPane.setBackground(Color.WHITE);
		add(scrollPane);	
		
	}
	
	// on click of album must populate album info
	public void setServerAlbumList() {
		albumData = new DefaultTableModel();
		albumData.setColumnIdentifiers(new Object[] {
			"",
			"Album",
		});
		for (int i = 0; i < 100; i++) {
			albumData.addRow(new Object[] {
				"",
				"Library Album" + i,
			});
		}
		table.setModel(albumData);
		albumView = true;
		table.getColumnModel().getColumn(0).setMaxWidth(20);
		table.getColumnModel().getColumn(0).setMinWidth(20);
		table.getColumnModel().getColumn(0).setPreferredWidth(20);
	}
	
	public Album getCurrentAlbum() {
		return currentAlbum;
	}
	
	public void setFavoriteAlbumList() {
		albumData = new DefaultTableModel();
		albumData.setColumnIdentifiers(new Object[] {
			"",
			"Album",
		});
		for (int i = 0; i < mainScreen.getCurrentUser().getFavoriteAlbumCount(); i++) {
			albumData.addRow(new Object[] {
					"",
					mainScreen.getCurrentUser().getFavoritesList().get(i).toString(),
			});
		}
		table.setModel(albumData);
		albumView = true;
		table.getColumnModel().getColumn(0).setMaxWidth(20);
		table.getColumnModel().getColumn(0).setMinWidth(20);
		table.getColumnModel().getColumn(0).setPreferredWidth(20);
	}
	
	private void getTrackList(Album album) {
		trackData = new DefaultTableModel();
		trackData.setColumnIdentifiers(new Object[] {
				"",
				"Track",
				"Album",
				"Artist",
				"Duration",
		});
		
		for (int i = 0; i < album.getTrackList().size(); i++) {
			trackData.addRow(new Object[] {
				"",
				album.getTrackList().get(i).getSongName(),
				album.getTrackList().get(i).getAlbum(),
				album.getTrackList().get(i).getArtist(),
				album.getTrackList().get(i).getDuration(),
			});
		}
		table.setModel(trackData);	
		table.getColumnModel().getColumn(0).setMaxWidth(20);
		table.getColumnModel().getColumn(0).setMinWidth(20);
		table.getColumnModel().getColumn(0).setPreferredWidth(20);
		mainScreen.getSidebar().setTrackView();
	}

	private class TableMouseListener extends MouseAdapter {
		
		@Override
		public void mouseEntered(MouseEvent arg0) {
			try {
				int currRow = table.rowAtPoint(arg0.getPoint());
				table.setRowSelectionInterval(currRow, currRow);
			} catch (IllegalArgumentException e) {
				table.clearSelection();
			}
		}
		
		@Override
		public void mouseMoved(MouseEvent arg0) {
			try {
				int currRow = table.rowAtPoint(arg0.getPoint());
				table.setRowSelectionInterval(currRow, currRow);
			} catch (IllegalArgumentException e) {
				table.clearSelection();
			}
		}
		
		@Override
		public void mouseExited(MouseEvent arg0) {
			table.clearSelection();
		}
		
		@Override
		public void mousePressed(MouseEvent arg0) {
			table.setSelectionBackground(HIGHLIGHTCOLOR);
		}
		
		@Override
		public void mouseReleased(MouseEvent arg0) {
			if (albumView) {
				try {
					currentAlbum = mainScreen.getCurrentUser().getFavoritesList().get(table.getSelectedRow());
					getTrackList(currentAlbum);
					albumView = false;
				} catch (ArrayIndexOutOfBoundsException e) {
				}
			} else {
				try {
					mainScreen.getPlayerControls().startSong(currentAlbum.getTrackList().get(table.getSelectedRow()));
				} catch (ArrayIndexOutOfBoundsException e) {
				}
			}
			table.setSelectionBackground(HOVERCOLOR);
		}
	}

}
