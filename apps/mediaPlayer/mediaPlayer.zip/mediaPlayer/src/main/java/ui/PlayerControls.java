package ui;


import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.ImageIcon;

import javax.swing.BoxLayout;
import java.awt.Component;
import javax.swing.SwingConstants;

import model.Track;
import techServices.FilePlayer;

import javax.media.CannotRealizeException;
import javax.media.NoPlayerException;
import javax.swing.Box;
import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JLabel;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;

/**
 * Displays and manages the PlayerControls ui.
 */
@SuppressWarnings("serial")
public class PlayerControls extends JPanel {
	private final Color PANELCOLOR = new Color(0,170,170);
	
	private final JButton btnPlay;
	private final ImageIcon playIcon = new ImageIcon(System.getProperty("user.dir") + "/res/play.png");
	private final ImageIcon playHoverIcon = new ImageIcon(System.getProperty("user.dir") + "/res/playHover.png");
	private final ImageIcon playPressedIcon = new ImageIcon(System.getProperty("user.dir") + "/res/playPressed.png");
	private final ImageIcon pauseIcon = new ImageIcon(System.getProperty("user.dir") + "/res/pause.png");
	private final ImageIcon pauseHoverIcon = new ImageIcon(System.getProperty("user.dir") + "/res/pauseHover.png");
	private final ImageIcon pausePressedIcon = new ImageIcon(System.getProperty("user.dir") + "/res/pausePressed.png");

	JLabel lblHeart;
	JLabel lblFavoriteThisSong;
	private boolean playing = false;
	private SeekBar seekBar;
	
	private JLabel txtTotalTimeLabel;
	private JLabel txtElapsedTimeLabel;
	private JLabel txtTitleLabel;
	
	private FilePlayer filePlayer;

	private boolean playerOn = false;
	private UpdateSongThread updateTimeThread;

	public PlayerControls(MainScreen mainScreen) {
		filePlayer = new FilePlayer();
		
		setBackground(PANELCOLOR);
		setLayout(new BorderLayout(0, 0));
		
		JPanel mainPanel = new JPanel();
		mainPanel.setBackground(PANELCOLOR);
		add(mainPanel, BorderLayout.CENTER);
		mainPanel.setLayout(new BorderLayout(0, 0));
		
		JPanel topPanel = new JPanel();
		topPanel.setMaximumSize(new Dimension(32767, 40));
		topPanel.setMinimumSize(new Dimension(10, 60));
		topPanel.setPreferredSize(new Dimension(10, 50));
		mainPanel.add(topPanel, BorderLayout.NORTH);
		topPanel.setLayout(new BorderLayout(0, 0));
		topPanel.setBackground(PANELCOLOR);
		
		JPanel namePanel = new JPanel();
		topPanel.add(namePanel, BorderLayout.NORTH);
		namePanel.setLayout(new BorderLayout(0, 0));
		namePanel.setBackground(PANELCOLOR);
		
		txtTitleLabel = new JLabel(" ", SwingConstants.CENTER);
		txtTitleLabel.setForeground(Color.WHITE);
		txtTitleLabel.setAlignmentX(0.5f);
		namePanel.add(txtTitleLabel);
		txtTitleLabel.setBackground(PANELCOLOR);
		
		Component verticalStrut = Box.createVerticalStrut(20);
		verticalStrut.setPreferredSize(new Dimension(0, 5));
		namePanel.add(verticalStrut, BorderLayout.SOUTH);
		
		Component verticalStrut_2 = Box.createVerticalStrut(20);
		verticalStrut_2.setPreferredSize(new Dimension(0, 5));
		namePanel.add(verticalStrut_2, BorderLayout.NORTH);
		
		JPanel seekPanel = new JPanel();
		topPanel.add(seekPanel, BorderLayout.CENTER);
		seekPanel.setLayout(new BoxLayout(seekPanel, BoxLayout.X_AXIS));
		seekPanel.setBackground(PANELCOLOR);
		
		Component MarginL = Box.createHorizontalStrut(20);
		seekPanel.add(MarginL);
		
		txtElapsedTimeLabel = new JLabel("    ");
		txtElapsedTimeLabel.setForeground(Color.WHITE);
		seekPanel.add(txtElapsedTimeLabel);
		
		Component progressSpaceL = Box.createHorizontalStrut(20);
		progressSpaceL.setPreferredSize(new Dimension(5, 0));
		seekPanel.add(progressSpaceL);
		
		seekBar = new SeekBar();
		MouseSeekAdapter mouseSeekAdapter = new MouseSeekAdapter();
		seekBar.addMouseListener(mouseSeekAdapter);
		seekBar.addMouseMotionListener(mouseSeekAdapter);
		seekBar.setAlignmentY(Component.CENTER_ALIGNMENT);
		seekPanel.add(seekBar);
		
		Component progressSpaceR = Box.createHorizontalStrut(20);
		progressSpaceR.setPreferredSize(new Dimension(5, 0));
		seekPanel.add(progressSpaceR);
		
		txtTotalTimeLabel = new JLabel("    ");
		txtTotalTimeLabel.setForeground(Color.WHITE);
		seekPanel.add(txtTotalTimeLabel);
		
		Component MarginR = Box.createHorizontalStrut(20);
		seekPanel.add(MarginR);
		
		JPanel panel = new JPanel();
		mainPanel.add(panel, BorderLayout.CENTER);
		panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
		panel.setBackground(PANELCOLOR);
		
		/* Play Pause Button */
		btnPlay = new JButton(playIcon);
		btnPlay.setFocusable(false);
		btnPlay.setBorder(null);
		btnPlay.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				if (playerOn)
					playClicked();
			}
		});
		
		Component horizontalStrut = Box.createHorizontalStrut(20);
		horizontalStrut.setMinimumSize(new Dimension(15, 0));
		horizontalStrut.setMaximumSize(new Dimension(15, 32767));
		horizontalStrut.setPreferredSize(new Dimension(15, 0));
		panel.add(horizontalStrut);
		btnPlay.setRolloverIcon(playHoverIcon);
		btnPlay.setPressedIcon(playPressedIcon);
		btnPlay.setContentAreaFilled(false);
		btnPlay.setAlignmentY(Component.BOTTOM_ALIGNMENT);
		panel.add(btnPlay);
			
		/* Back Button */
		ImageIcon prevIcon = new ImageIcon(System.getProperty("user.dir") + "/res/prev.png");
		ImageIcon prevHoverIcon = new ImageIcon(System.getProperty("user.dir") + "/res/prevHover.png");
		ImageIcon prevPressedIcon = new ImageIcon(System.getProperty("user.dir") + "/res/prevPressed.png");
		
		Component horizontalStrut_1 = Box.createHorizontalStrut(20);
		horizontalStrut_1.setMaximumSize(new Dimension(35, 32767));
		horizontalStrut_1.setMinimumSize(new Dimension(35, 0));
		horizontalStrut_1.setPreferredSize(new Dimension(35, 0));
		panel.add(horizontalStrut_1);
		JButton btnPrev = new JButton(prevIcon);
		btnPrev.setBorder(null);
		btnPrev.setFocusPainted(false);
		btnPrev.setRolloverIcon(prevHoverIcon);
		btnPrev.setPressedIcon(prevPressedIcon);
		btnPrev.setContentAreaFilled(false);
		btnPrev.setAlignmentY(Component.BOTTOM_ALIGNMENT);
		panel.add(btnPrev);
		
		/* Stop Button */
		ImageIcon stopIcon = new ImageIcon(System.getProperty("user.dir") + "/res/stop.png");
		ImageIcon stopHoverIcon = new ImageIcon(System.getProperty("user.dir") + "/res/stopHover.png");
		ImageIcon stopPressedIcon = new ImageIcon(System.getProperty("user.dir") + "/res/stopPressed.png");
		
		Component horizontalStrut_2 = Box.createHorizontalStrut(20);
		horizontalStrut_2.setMaximumSize(new Dimension(30, 32767));
		horizontalStrut_2.setMinimumSize(new Dimension(30, 0));
		horizontalStrut_2.setPreferredSize(new Dimension(30, 0));
		panel.add(horizontalStrut_2);
		JButton btnStop = new JButton(stopIcon);
		btnStop.setBorder(null);
		btnStop.setFocusPainted(false);
		btnStop.setRolloverIcon(stopHoverIcon);
		btnStop.setPressedIcon(stopPressedIcon);
		btnStop.setContentAreaFilled(false);
		btnStop.setAlignmentY(Component.BOTTOM_ALIGNMENT);
		panel.add(btnStop);
		
		btnStop.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				if (playerOn)
					stopSong();
			}
		});
		
		/* Next Button */
		ImageIcon nextIcon = new ImageIcon(System.getProperty("user.dir") + "/res/next.png");
		ImageIcon nextHoverIcon = new ImageIcon(System.getProperty("user.dir") + "/res/nextHover.png");
		ImageIcon nextPressedIcon = new ImageIcon(System.getProperty("user.dir") + "/res/nextPressed.png");
		
		Component horizontalStrut_3 = Box.createHorizontalStrut(20);
		horizontalStrut_3.setPreferredSize(new Dimension(30, 0));
		horizontalStrut_3.setMinimumSize(new Dimension(30, 0));
		horizontalStrut_3.setMaximumSize(new Dimension(30, 32767));
		panel.add(horizontalStrut_3);
		JButton btnNext = new JButton(nextIcon);
		btnNext.setBorder(null);
		btnNext.setFocusPainted(false);
		btnNext.setRolloverIcon(nextHoverIcon);
		btnNext.setPressedIcon(nextPressedIcon);
		btnNext.setContentAreaFilled(false);
		btnNext.setAlignmentY(Component.BOTTOM_ALIGNMENT);
		panel.add(btnNext);
		
		Component verticalStrut_1 = Box.createVerticalStrut(20);
		verticalStrut_1.setPreferredSize(new Dimension(0, 8));
		mainPanel.add(verticalStrut_1, BorderLayout.SOUTH);		
	}
	
	private void playClicked() {
		if (playing) {
			btnPlay.setIcon(playIcon);
			btnPlay.setRolloverIcon(playHoverIcon);
			btnPlay.setPressedIcon(playPressedIcon);
			
			updateTimeThread.pause();
			filePlayer.pauseSong();
			
			playing = false;
		}
		else {
			btnPlay.setIcon(pauseIcon);
			btnPlay.setRolloverIcon(pauseHoverIcon);
			btnPlay.setPressedIcon(pausePressedIcon);
			
			updateTimeThread.play();
			filePlayer.startSong();
			
			playing = true;
		}
	}
	
	private class MouseSeekAdapter extends MouseAdapter {		
		@Override
		public void mousePressed(MouseEvent e) {
			updateTimeThread.pause();
			seekBar.setLocation(e.getPoint().x);
		}

		@Override
		public void mouseDragged(MouseEvent e) {
			seekBar.setLocation(e.getPoint().x);
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			seekBar.setLocation(e.getPoint().x);
			filePlayer.setTime(seekBar.getValue());
			updateTimeThread.play();
		}
	}

	public void startSong(Track track) {
		if (playing) {
			stopSong();
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
			}
		}
		
		txtTitleLabel.setText(track.getSongName());
		txtTotalTimeLabel.setText(track.getDuration());
		txtElapsedTimeLabel.setText("0:00");
			
		btnPlay.setIcon(pauseIcon);
		btnPlay.setRolloverIcon(pauseHoverIcon);
		btnPlay.setPressedIcon(pausePressedIcon);
		playing = true;
		playerOn = true;
		
		try {
			filePlayer.prepareSong(System.getProperty("user.dir") + "/download/" + track.getFileName());
		} catch (NoPlayerException | CannotRealizeException | IOException e) {
			e.printStackTrace();
		}
		seekBar.setMaxValue(filePlayer.getTotalMilliseconds());
		seekBar.enable();
		updateTimeThread = new UpdateSongThread();
		updateTimeThread.start();
		filePlayer.startSong();	
	}
	
	private void stopSong() {
		filePlayer.stopSong();
		
		txtTitleLabel.setText(" ");
		txtTotalTimeLabel.setText("    ");
		txtElapsedTimeLabel.setText("    ");
		
		btnPlay.setIcon(playIcon);
		btnPlay.setRolloverIcon(playHoverIcon);
		btnPlay.setPressedIcon(playPressedIcon);
		
		seekBar.setValue(0);
		seekBar.disable();
		
		playerOn = false;
		playing = false;
	}
	
	private class UpdateSongThread extends Thread {
		private boolean paused;
		public void run() {
			playerOn = true;
			paused = false;
			while (playerOn) {
				try {
					Thread.sleep(100);
					while (paused && playerOn)
						Thread.sleep(100);
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt();
				}
				seekBar.setValue(filePlayer.getElapsedMilliseconds());
				txtElapsedTimeLabel.setText(filePlayer.getElapsedString());
				playerOn = !filePlayer.isFinished();
			}
			stopSong();
		}
		
		public void pause() {
			paused = true;
		}
		
		public void play() {
			paused = false;
		}
	}
}
