package ui;

import javax.swing.JFrame;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.Box;

import javax.swing.border.EmptyBorder;
import javax.swing.JPasswordField;
import javax.swing.JLabel;

import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Dimension;

import javax.swing.BoxLayout;
import javax.swing.JPanel;
import java.awt.Component;
import javax.swing.border.LineBorder;

import model.SettingsAccess;
import model.User;
import techServices.AuthenticationController;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * Creates the AuthScreen window. This class gets the user and password and 
 * uses the authentication controller to determine password correctness.
 */
@SuppressWarnings("serial")
public class AuthScreen extends JFrame{
	final Color HIGHLIGHTCOLOR = new Color(0,150,150);
	final Color HOVERCOLOR = new Color(50 ,200, 200);
	
	private JPanel userPicPanel;
	UserMouseListener userMouseListener = new UserMouseListener();
	JLabel selectedUserPic = null;
	JLabel selectedUser;
	private Component verticalStrut_1;
	private Component verticalStrut_2;
	private JLabel lblEnterPin;
	private JLabel lblWrongPin;
	private JPasswordField passwordField;
	private JButton btnEnter;
	private Component verticalStrut_3;
	private AuthenticationController authCtrl;
	
	public AuthScreen() {
		getContentPane().setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));
		authCtrl = new AuthenticationController();
		
		this.setPreferredSize(new Dimension(400,200));
		
		userPicPanel = new JPanel();
		userPicPanel.setOpaque(false);
		getUsers();
		getContentPane().add(userPicPanel);
				
		Component verticalStrut = Box.createVerticalStrut(10);
		getContentPane().add(verticalStrut);
		
		selectedUser = new JLabel(" ");		
		getContentPane().add(selectedUser);
		
		verticalStrut_1 = Box.createVerticalStrut(10);
		getContentPane().add(verticalStrut_1);
		
		JPanel pnlPassword = new JPanel();
		pnlPassword.setOpaque(false);
		getContentPane().add(pnlPassword);
		
		lblEnterPin = new JLabel("Enter Pin: ");
		pnlPassword.add(lblEnterPin);
		
		passwordField = new JPasswordField();
		passwordField.setColumns(5);
		pnlPassword.add(passwordField);
		
		lblWrongPin = new JLabel("Wrong PIN");
		lblWrongPin.setVisible(false);
		lblWrongPin.setForeground(Color.RED);
		pnlPassword.add(lblWrongPin);
		
		verticalStrut_2 = Box.createVerticalStrut(10);
		getContentPane().add(verticalStrut_2);
		
		btnEnter = new JButton("Enter");
		btnEnter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				enterButtonClicked();
			}
		});
		this.getRootPane().setDefaultButton(btnEnter);
		getContentPane().add(btnEnter);
		
		verticalStrut_3 = Box.createVerticalStrut(10);
		getContentPane().add(verticalStrut_3);
		
		
		this.pack();	
	
	}
	
	protected void enterButtonClicked() {
		if(passwordField.getText().length() != 4){
			lblWrongPin.setVisible(true);
			passwordField.setText("");
		}
		
		User userSelected = authCtrl.getUserWithName(selectedUser.getText());
		if(authCtrl.checkPIN(userSelected, passwordField.getText())){
			startMediaPlayer(userSelected);
		} else{
			lblWrongPin.setVisible(true);
			passwordField.setText("");
		}
		
	}

	private void getUsers() {
		for(User u: (new SettingsAccess()).getSettings().getUsers()){
			ImageIcon image = new ImageIcon(u.getImageLocation());
			JLabel imageLabel = new JLabel(image);
			imageLabel.setName(u.getName());
			imageLabel.setBorder(new EmptyBorder(3, 3, 3, 3));

			
			imageLabel.addMouseListener(userMouseListener);
			imageLabel.addMouseMotionListener(userMouseListener);
			userPicPanel.add(imageLabel);
			Component horizontalStrut = Box.createHorizontalStrut(10);
			userPicPanel.add(horizontalStrut);
		}
	}

	private void startMediaPlayer(User userSelected) {
		MainScreen frame = new MainScreen(userSelected);
		frame.setSize(800, 640);
		frame.setVisible(true);
		frame.setMinimumSize(new Dimension(500, 400));
		frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		AuthScreen.super.dispose();
	}
	
	private class UserMouseListener extends MouseAdapter {
		
		
		@Override
		public void mouseEntered(MouseEvent arg0) {
			if (!arg0.getSource().equals(selectedUserPic)) {
				JLabel image = (JLabel) arg0.getSource();
				image.setBorder(new LineBorder(HOVERCOLOR, 3));
			}
		}
		
		@Override
		public void mouseExited(MouseEvent arg0) {
			if (!arg0.getSource().equals(selectedUserPic)) {
				JLabel image = (JLabel) arg0.getSource();
				image.setBorder(new EmptyBorder(3,3,3,3));
			}
		}
		
		@Override
		public void mouseClicked(MouseEvent arg0) {
			if (selectedUserPic != null) {
				selectedUserPic.setBorder(new EmptyBorder(3,3,3,3));
			}
			selectedUserPic = (JLabel) arg0.getSource();
			selectedUserPic.setBorder(new LineBorder(HIGHLIGHTCOLOR, 3));
			selectedUser.setText(selectedUserPic.getName());
		}
		
		@Override
		public void mousePressed(MouseEvent arg0) {
			if (selectedUserPic != null) {
				selectedUserPic.setBorder(new EmptyBorder(3,3,3,3));
			}
			selectedUserPic = (JLabel) arg0.getSource();
			selectedUserPic.setBorder(new LineBorder(HIGHLIGHTCOLOR, 3));
			selectedUser.setText(selectedUserPic.getName());
		}
	}
}
