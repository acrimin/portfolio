package techServices;

import java.io.File;

/**
 * Controls the adding and removing of albums.
 */
public class DataManager {

	public DataManager() {
	}
	
	/**
	 * Not implemented - should download album to downloads folder
	 * @param albumURL url of album
	 */
	public void downloadAlbum(String albumURL) {
		
	}
	
	/**
	 * Deletes all items in folder then deletes folder
	 * @param albumName name of directory of album to be removed
	 */
	public void removeAlbum(String albumName) {
		File index = new File(System.getProperty("user.dir") + "/download/" + albumName);
		String [] entries = index.list();
		for (String s: entries) {
			File currentFile = new File(index.getPath(),s);
			currentFile.delete();
		}
		index.delete();
	}

}
