package techServices;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;

import javax.media.CannotRealizeException;
import javax.media.Controller;
import javax.media.Format;
import javax.media.Manager;
import javax.media.MediaLocator;
import javax.media.NoPlayerException;
import javax.media.Player;
import javax.media.PlugInManager;
import javax.media.Time;
import javax.media.format.AudioFormat;

/**
 * Manages the media player.
 */
public class FilePlayer {
	private Player player;

	/**
	 * Creates the mediaplayer to play mp3 files
	 */
	public FilePlayer() {
		Format input1 = new AudioFormat(AudioFormat.MPEGLAYER3);
		Format input2 = new AudioFormat(AudioFormat.MPEG);
		Format output = new AudioFormat(AudioFormat.LINEAR);
		PlugInManager.addPlugIn("com.sun.media.codec.audio.mp3.JavaDecoder",
				new Format[] { input1, input2 }, new Format[] { output },
				PlugInManager.CODEC);
		
		
	}
	
	/**
	 * preps media player to be played
	 * @param fileLocation fileLocation of song to be played
	 */
	public void prepareSong(String fileLocation) throws NoPlayerException, CannotRealizeException, MalformedURLException, IOException {
		player = Manager.createRealizedPlayer(new MediaLocator(
				new File(fileLocation).toURI().toURL()));
	}
	
	/**
	 * starts song
	 */
	public void startSong() {
		player.start();
	}
	
	/**
	 * pauses song
	 */
	public void pauseSong() {
		player.stop();
	}
	
	/**
	 * stops song and resets media player
	 */
	public void stopSong() {
		player.stop();
		player.close();
	}
	
	/**
	 * @return whether the song is finished yet
	 */
	public boolean isFinished() {
		return (player.getState() == Controller.Prefetched);
	}
	
	/**
	 * @return milliseconds in song playing
	 */
	public int getTotalMilliseconds() {
		return nanoToMilli(player.getDuration().getNanoseconds());
	}
	
	/**
	 * @param milliseconds sets time to milliseconds given
	 */
	public void setTime(int milliseconds) {
		player.setMediaTime(new Time(milliToNano(milliseconds)));
	}
	
	/**
	 * @return elapsed milliseconds in song
	 */
	public int getElapsedMilliseconds() {
		return nanoToMilli(player.getMediaNanoseconds());
	}
	
	/**
	 * @return gets time in 0:00 format
	 */
	public String getElapsedString() {
		double totalSeconds = player.getMediaTime().getSeconds();
		
		int minutes = (int) Math.floor(totalSeconds / 60);
		int seconds = (int) (Math.floor(totalSeconds) - (minutes*60));
	
		return String.format("%d:%02d", minutes, seconds);
	}
	
	private int nanoToMilli(long nanoseconds) {
		return (int) (nanoseconds / 1000000);
	}
	
	private long milliToNano(int milliseconds) {
		return (long) milliseconds * 1000000;
	}

}
