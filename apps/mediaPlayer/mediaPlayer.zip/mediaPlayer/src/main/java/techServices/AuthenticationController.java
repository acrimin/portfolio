/* Author: Matt Moersen 
 * CPSC 3720 Spring 2016
 * Project Phase 3
 * Copyright (c) 2016
 */
package techServices;

import java.util.ArrayList;

import model.SettingsAccess;
import model.User;


/* Class AuthenticationController
 * 
 * Variables:
 * 	ArrayList<User> users - a list of users on the system
 * 
 * Summary:
 * 	This class authenticates a User with a PIN
 */

public class AuthenticationController {
	
	ArrayList<User> users;
	
	
	
	/* AuthenticationController Constructor
	 * 
	 * Parameters:
	 * 	NONE
	 * 
	 * Summary:
	 * 	Gets a list of users on the system
	 */
	public AuthenticationController(){
		users = (new SettingsAccess()).getSettings().getUsers();
	}
	
	/* Method getUserWithName
	 * 
	 * Parameters:
	 * 	String name - name of selected user on the authentication screen
	 * 
	 * Summary:
	 * 	With a given username, return the User Object
	 */
	public User getUserWithName(String name){
		for(User u : users){
			if(u.getName().equals(name)){
				return u;
			}
		}
		
		return null;
		
	}

	/* Method checkPIN
	 * 
	 * Parameters:
	 * 	User u - a User Object
	 * 	String pin - inputed PIN code
	 * 
	 * Summary:
	 * 	If PIN code matches what is in the User Object, returns true
	 * 
	 */
	public boolean checkPIN(User u, String pin){
		if(u.getPIN().equals(pin)){
			return true;
		} else {
			return false;
		}
	}
	
}