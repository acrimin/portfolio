package model;

/**
 * Holds settings class to be accessed anywhere
 */
public class SettingsAccess {
	private static Settings settings;

	public SettingsAccess() {
	}
	
	public void updateSettings(Settings settings) {
		SettingsAccess.settings = settings;
	}
	
	public Settings getSettings() {
		return settings;
	}

}
