package model;

/**
 * Contains all Track information
 * songName
 * artist
 * duration
 * fileName
 * album
 */
public class Track {
	private String songName;
	private String artist;
	private String duration;
	private String fileName;
	private String album;
	private boolean local;
	
	public Track() {
		songName = "Not Set";
		setAlbum("Not Set");
		artist = "Not Set";
		duration = "0:00";
		fileName = "/";
		local = false;
	}

	public String getSongName() {
		return songName;
	}

	public void setSongName(String songName) {
		this.songName = songName;
	}

	public String getArtist() {
		return artist;
	}

	public void setArtist(String artist) {
		this.artist = artist;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public boolean isLocal() {
		return local;
	}

	public void setLocal(boolean local) {
		this.local = local;
	}

	public String getAlbum() {
		return album;
	}

	public void setAlbum(String album) {
		this.album = album;
	}

}
