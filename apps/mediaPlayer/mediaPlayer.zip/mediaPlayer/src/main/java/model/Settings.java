package model;

import java.util.ArrayList;

/**
 * Contains all settings for application
 */
public class Settings {
	private ArrayList<User> users;
	private String serverURL;
	private ArrayList<ArrayList<Album>> approvedAlbums;
	

	/**
	 * Instantiates default settings
	 */
	public Settings() {		
		setServerURL("http://127.0.0.1:5001/upnp/control/content_directory"); 
		users = new ArrayList<User>();
		approvedAlbums = new ArrayList<ArrayList<Album>>();
		
		Album albumA = new Album();
		albumA.setName("Album A");
			Track track = new Track();
			track.setSongName("I. Allegro ma non troppo");
			track.setArtist("European Archive");
			track.setAlbum("Violin Concerto in D, Op. 61");
			track.setDuration("0:30");
			track.setFileName("Album A/Track 1.mp3");
			track.setLocal(true);
		albumA.addTrack(track);
		
			track = new Track();
			track.setSongName("II. Larghetto");
			track.setArtist("European Archive");
			track.setAlbum("Violin Concerto in D, Op. 61");
			track.setDuration("0:30");
			track.setFileName("Album A/Track 2.mp3");
			track.setLocal(true);
		albumA.addTrack(track);	
			
			track = new Track();
			track.setSongName("III. Rondo (Allegro)");
			track.setArtist("European Archive");
			track.setAlbum("Violin Concerto in D, Op. 61");
			track.setDuration("0:31");
			track.setFileName("Album A/Track 3.mp3");
			track.setLocal(true);
		albumA.addTrack(track);
		
		Album albumB = new Album();
		albumB.setName("Album B");
			track = new Track();
			track.setSongName("Movement 1");
			track.setArtist("Claremont Trio");
			track.setAlbum("Mendelssohn Piano Trio No. 1");
			track.setDuration("0:08");
			track.setFileName("Album B/mendelssohn1.mp3");
			track.setLocal(true);
		albumB.addTrack(track);
	
			track = new Track();
			track.setSongName("Movement 2");
			track.setArtist("Claremont Trio");
			track.setAlbum("Mendelssohn Piano Trio No. 1");
			track.setDuration("0:13");
			track.setFileName("Album B/mendelssohn2.mp3");
			track.setLocal(true);
		albumB.addTrack(track);	
		
			track = new Track();
			track.setSongName("Movement 3");
			track.setArtist("Claremont Trio");
			track.setAlbum("Mendelssohn Piano Trio No. 1");
			track.setDuration("0:09");
			track.setFileName("Album B/mendelssohn3.mp3");
			track.setLocal(true);
		albumB.addTrack(track);	
	
		Album albumC = new Album();
		albumC.setName("Album C");
		
		User user = new User();
		user.setName("Admin");
		user.setAdmin(true);
		user.setPIN("9999");
		user.setImageName("person1.png");
		users.add(user);
		
		User user1 = new User();		
		user1.setName("Child 1");
		user1.setAdmin(false);
		user1.setPIN("1111");
		user1.setRestrictLevel(2);
		user1.addFavoriteAlbum(albumA);
		user1.setImageName("person4.png");
		users.add(user1);
		
		User user2 = new User();
		user2.setName("Child 2");
		user2.setAdmin(false);
		user2.setPIN("2222");
		user2.setRestrictLevel(3);
		user2.addFavoriteAlbum(albumA);
		user2.addFavoriteAlbum(albumB);
		user2.setImageName("person5.png");
		users.add(user2);
		
		setRestrictionLevelCount(3);
		
		addAlbumToLevel(albumA, 1);
		addAlbumToLevel(albumB, 3);
		addAlbumToLevel(albumC, 3);
	}
	
	public int getUserCount() {
		return users.size();
	}
	
	public User getUser(int index) {
		return users.get(index);
	}

	public void addUser(User user) {
		users.add(user);
	}

	public ArrayList<User> getUsers(){
		return users;
	}
	
	public String getServerURL() {
		return serverURL;
	}

	public void setServerURL(String serverURL) {
		this.serverURL = serverURL;
	}
	
	public void setRestrictionLevelCount(int count) {
		approvedAlbums.clear();
		for (int i = 0; i < count; i++) {
			approvedAlbums.add(new ArrayList<Album>());
		}
	}
	
	public void addAlbumToLevel(Album albumA, int level) {
		approvedAlbums.get(level - 1).add(albumA);
	}
	
	public Album[] getApprovedAlbums(int level) {
		Album[] approvedArray = new Album[approvedAlbums.get(level - 1).size()];
		approvedArray = approvedAlbums.get(level - 1).toArray(approvedArray);
		return approvedArray;
	}

	public boolean isAlbumFavorited(Album album) {
		for (int i = 0; i < users.size(); i++) {
			if (users.get(i).getFavoritesList().contains(album)) 
				return true;
		}
		
		return false;
	}
}
