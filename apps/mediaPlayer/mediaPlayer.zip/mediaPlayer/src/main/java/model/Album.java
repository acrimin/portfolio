package model;

import java.util.ArrayList;

/**
 * Contains album information
 * Name
 * List of tracks
 */
public class Album {
	private String name;
	private ArrayList<Track> tracks;
	
	public Album() {
		tracks = new ArrayList<Track>();
		name = "Not Set";
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String toString() {
		return name;
	}
	
	public void addTrack(Track track) {
		tracks.add(track);
	}
	
	public ArrayList<Track> getTrackList() {
		return tracks;
	}
	
	public boolean isFavorited() {
		return (new SettingsAccess()).getSettings().isAlbumFavorited(this);
	}

}
