package model;

import java.util.ArrayList;

import techServices.DataManager;

/**
 * Contains all user information
 * name
 * PIN
 * imageID
 * admin status
 * list of favorite albums
 */
public class User {
	private String name;
	private String PIN;
	private String imageLocation;
	private boolean admin;
	private int restrictLevel;
	ArrayList<Album> favoriteAlbums;
	String imageFolder = System.getProperty("user.dir") + "/res/";
	

	public User() {	
		favoriteAlbums = new ArrayList<Album>();
		
		name = "Unset";
		PIN = "0000";
		setImageName("person1.png");
		admin = true;
	}

	public int getFavoriteAlbumCount() {
		return favoriteAlbums.size();
	}

	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getPIN() {
		return PIN;
	}


	public void setPIN(String pIN) {
		PIN = pIN;
	}


	public String getImageLocation() {
		return imageLocation;
	}


	public void setImageName(String imageLocation) {
		this.imageLocation = imageFolder + imageLocation;
	}


	public boolean isAdmin() {
		return admin;
	}
	
	public String isAdminString() {
		if (admin) 
			return "Admin";
		return "Regular";
	}


	public void setAdmin(boolean admin) {
		this.admin = admin;
	}


	public int getRestrictLevel() {
		return restrictLevel;
	}


	public void setRestrictLevel(int restrictLevel) {
		this.restrictLevel = restrictLevel;
	}

	public void addFavoriteAlbum(Album favoriteAlbum) {
		this.favoriteAlbums.add(favoriteAlbum);
	}
	
	public String toString() {
		return name;
	}
	
	public ArrayList<Album> getFavoritesList() {
		return favoriteAlbums;
	}
	
	public void removeAlbumFromFavorites(Album album) {
		favoriteAlbums.remove(album);
		if (!(new SettingsAccess()).getSettings().isAlbumFavorited(album))
			(new DataManager()).removeAlbum(album.toString());
		
	}

}
