You can drop plugins (.jar files) here or move them to another directory and set

    # Linux, Mac OS X &c.
    plugins = /path/to/plugins/dir

or:

    # Windows
    plugins = C:\\Path\\To\\Plugins\\Dir

in UMS.conf

You can find a list of available plugins at:
http://www.universalmediaserver.com/plugins/
Or simply use the installer on the Plugin Management page in the program

For information on developing plugins, see https://github.com/UniversalMediaServer/UniversalMediaServer/tree/master/src/main/external-resources/plugins/README.md