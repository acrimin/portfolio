#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include <GL/glx.h>
#include <GL/glext.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <math.h>

typedef struct {
    float x, y, z;
} Point3;

typedef struct {
    float x, y;
} Point2;

typedef struct {
    Point3 quad[4];
    Point3 normal;
    Point2 texture[4];
    GLfloat diffuse[4];
    GLfloat specular[4];
    GLfloat shininess[1];
} Plane;

Point3 vectors[32767];
Point3 normals[32767];
Point2 textures[32767];
Point3 tangentsX[32767];
Point3 tangentsY[32767];
int faceVec[32767][4];
int faceNorm[32767][4];
int faceTex[32767][4];
extern int face;

float dot(Point3 a, Point3 b);
Point3 vecAdd(Point3 a, Point3 b);
Point3 vecScale(Point3 a, float scale);
Point3 vecSub(Point3 a, Point3 b);
Point3 normalize(Point3 a);
Point3 cross(Point3 a, Point3 b);
float length(Point3 a);
char *read_shader_program(char *filename);
void loadTeapot();
float radicalInverse(uint bits);
Point2 hammersley2d(uint i, uint N);
Point3 hemisphereSample(float u, float v);
unsigned int set_shaders(int s);
void load_texture(char *filename, unsigned int tid);
