#include "teapot.h"

float dot(Point3 a, Point3 b) {
    return a.x * b.x + a.y * b.y + a.z * b.z;
}

Point3 vecAdd(Point3 a, Point3 b) {
    Point3 c = {a.x + b.x, a.y + b.y, a.z + b.z};
    return c;
}

Point3 vecSub(Point3 a, Point3 b) {
    Point3 c = {a.x - b.x, a.y - b.y, a.z - b.z};
    return c;
}

Point3 normalize(Point3 a) {
    return vecScale(a,1/length(a));
}

float length(Point3 a) {
    return sqrt(a.x*a.x + a.y*a.y + a.z*a.z);
}

Point3 cross(Point3 a, Point3 b) {
    Point3 c;
    c.x = a.y * b.z - b.y * a.z;
    c.y = b.x * a.z - a.x * b.z;
    c.z = a.x * b.y - b.x * a.y; 
    return c;
}

Point3 vecScale(Point3 a, float scale) {
    a.x *= scale;
    a.y *= scale;
    a.z *= scale;
    return a;
}

char *read_shader_program(char *filename) {
    FILE *fp;
    char *content = NULL;
    int fd, count;
    fd = open(filename,O_RDONLY);
    count = lseek(fd,0,SEEK_END);
    close(fd);
    content = (char *)calloc(1,(count+1));
    fp = fopen(filename,"r");
    count = fread(content,sizeof(char),count,fp);
    content[count] = '\0';
    fclose(fp);
    return content;
}

int face = 0;
void loadTeapot() {
    FILE *fp = fopen("teapot.605.obj","r");
    int v = 0;
    int vn = 0;
    int vt = 0;
    int vx = 0;
    int vy = 0;

    char line[256];
    char* word;

    while (fgets(line, sizeof(line), fp)) {
        if (strncmp(line, "v ", 2) == 0) {
            word = strtok(line, " ");
            word = strtok(NULL, " ");
            vectors[v].x = atof(word);
            word = strtok(NULL, " ");
            vectors[v].y = atof(word);
            word = strtok(NULL, " ");
            vectors[v].z = atof(word);

            v++;
        }
        else if (strncmp(line, "vn ", 3) == 0) {
            word = strtok(line, " ");
            word = strtok(NULL, " ");
            normals[vn].x = atof(word);
            word = strtok(NULL, " ");
            normals[vn].y = atof(word);
            word = strtok(NULL, " ");
            normals[vn].z = atof(word);
            vn++;
        } 
        else if (strncmp(line, "vt ", 3) == 0) {
            word = strtok(line, " ");
            word = strtok(NULL, " ");
            textures[vt].x = atof(word);
            word = strtok(NULL, " ");
            textures[vt].y = atof(word);
            vt++;
        } 
        else if (strncmp(line, "vx ", 3) == 0) {
            word = strtok(line, " ");
            word = strtok(NULL, " ");
            tangentsX[vx].x = atof(word);
            word = strtok(NULL, " ");
            tangentsX[vx].y = atof(word);
            word = strtok(NULL, " ");
            tangentsX[vx].z = atof(word);
            vx++;
        }
        else if (strncmp(line, "vy ", 3) == 0) {
            word = strtok(line, " ");
            word = strtok(NULL, " ");
            tangentsY[vy].x = atof(word);
            word = strtok(NULL, " ");
            tangentsY[vy].y = atof(word);
            word = strtok(NULL, " ");
            tangentsY[vy].z = atof(word);
            vy++;
        }
        else if (strncmp(line, "f ", 2) == 0) {
            word = strtok(line, " ");

            int i;
            for (i = 0; i < 4; i++) {
                word = strtok(NULL, "/");
                faceVec[face][i] = atof(word);
                word = strtok(NULL, "/");
                faceTex[face][i] = atof(word);
                word = strtok(NULL, " ");
                faceNorm[face][i] = atof(word);
            }

            face++;
        }
    }
}

// invert number
float radicalInverse(uint bits) {
    bits = (bits << 16u) | (bits >> 16u);
    bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
    bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
    bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
    bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
    return (float)bits * 2.3283064365386963e-10; // / 0x100000000
}


// get hammersley random number
Point2 hammersley2d(uint i, uint N) {
    Point2 a = {(float)i/(float)N, radicalInverse(i)};
    return a;
}

// get point on hemisphere
Point3 hemisphereSample(float u, float v) {
    float PI = 3.14159265;
    float phi = v * 2.0 * PI;
    float cosTheta = (1.0 - u);
    float sinTheta = sqrt(1.0 - cosTheta * cosTheta);

    Point3 a = {cos(phi) * sinTheta, cosTheta, sin(phi) * sinTheta};
    return a;
}

unsigned int set_shaders(int s) {
    GLint vertCompiled, fragCompiled;
    char *vs, *fs;
    GLuint v, f, p;
    int result = -1;

    v = glCreateShader(GL_VERTEX_SHADER);
    f = glCreateShader(GL_FRAGMENT_SHADER);
    if (s == 1) {
        vs = read_shader_program("teapot_texture.vert");
        fs = read_shader_program("teapot_texture.frag");
    } else if (s == 2) {
        vs = read_shader_program("teapot_normal.vert");
        fs = read_shader_program("teapot_normal.frag");
    } else {
        vs = read_shader_program("teapot.vert");
        fs = read_shader_program("teapot.frag");
    }
    glShaderSource(v,1,(const char **)&vs,NULL);
    glShaderSource(f,1,(const char **)&fs,NULL);
    free(vs);
    free(fs); 
    glCompileShader(v);
    glCompileShader(f);
    glGetShaderiv(f,GL_COMPILE_STATUS,&result);
    fprintf(stderr,"%d\n",result);
    p = glCreateProgram();
    glAttachShader(p,f);
    glAttachShader(p,v);
    glLinkProgram(p);
//    glUseProgram(p);
    return(p);
}

void load_texture(char *filename, unsigned int tid) {
    FILE *fopen(), *fptr;
    char buf[512];
    int im_size, im_width, im_height, max_color;
    unsigned char *texture_bytes, *parse; 

    fptr=fopen(filename,"r");
    fgets(buf,512,fptr);
    do{
        fgets(buf,512,fptr);
    } while(buf[0]=='#');
    parse = strtok(buf," \t");
    im_width = atoi(parse);

    parse = strtok(NULL," \n");
    im_height = atoi(parse);

    fgets(buf,512,fptr);
    parse = strtok(buf," \n");
    max_color = atoi(parse);

    im_size = im_width*im_height;
    texture_bytes = (unsigned char *)calloc(3,im_size);
    fread(texture_bytes,3,im_size,fptr);
    fclose(fptr);

    // glBindTexture(GL_TEXTURE_2D,1);
    glBindTexture(GL_TEXTURE_2D,tid);
    glTexImage2D(GL_TEXTURE_2D,0,GL_RGB,im_width,im_height,0,GL_RGB, 
        GL_UNSIGNED_BYTE,texture_bytes);
    glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
    glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
    // added
    glTexEnvf(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_REPLACE);
    cfree(texture_bytes);
}

