#include "teapot.h"

#define XRES 1280 
#define YRES 1024 

Plane box[5]= {
// left red
{-3.5,0.0,4.0 , 5.0,0.0,4.0 , 5.0,5.0,4.0 , -3.5,5.0,4.0 , 0.0,0.0,-1.0 , 
0.0,0.0, 0.0,1.0 , 1.0,1.0 , 1.0,0.0 , 
0.798,0.133,0.133,1.0 , 0.798,0.133,0.133,1.0 , 10.0 },
// right green
{-3.5,0.0,-4.0 , -3.5,5.0,-4.0 , 5.0,5.0,-4.0 , 5.0,0.0,-4.0 , 0.0,0.0,1.0 ,
0.0,0.0, 1.0,0.0 , 1.0,1.0 , 0.0,1.0 , 
0.133,0.545,0.133,1.0 , 0.233,0.445,0.233,1.0 , 10.0 },
// back white
{-3.5,0.0,-4.0 , -3.5,0.0,4.0 , -3.5,5.0,4.0 , -3.5,5.0,-4.0 , 1.0,0.0,0.0 ,
0.0,0.0, 0.0,1.0 , 1.0,1.0 , 1.0,0.0 , 
1.0,0.99,0.88,1.0 , 1.0,0.99,0.88,1.0 , 1.0 },
// top white
{-3.5,5.0,-4.0 , -3.5,5.0,4.0 , 5.0,5.0,4.0 , 5.0,5.0,-4.0 , 0.0,-1.0,0.0 ,
0.0,0.0, 0.0,1.0 , 1.0,1.0 , 1.0,0.0 , 
1.0,0.99,0.88,1.0 , 1.0,0.99,0.88,1.0 , 1.0 },
// bottom wood 
{-3.5,-0.0,-4.0 , -3.5,-0.0,4.0 , 5.0,-0.0,4.0 , 5.0,-0.0,-4.0 , 0.0,1.0,0.0 ,
0.0,0.0, 0.0,1.0 , 1.0,1.0 , 1.0,0.0 , 
0.598,0.369,0.302,1.0 , 0.798,0.469,0.402,1.0 , 400.0 }};

GLfloat light0_diffuse[] = { 0.0, 0.0, 0.0, 1.0 };
GLfloat light0_specular[] = { 0.0, 0.0, 0.0, 1.0 };
GLfloat light0_position[] = { 1.0, 4.5, 0.0, 1.0 };
GLfloat light0_direction[] = { 0.0, -1, 0.0, 1.0 };

GLfloat light1_diffuse[] = { 0.0, 0.7, 0.0, 1.0 };
GLfloat light1_specular[] = { 0.0, 0.7, 0.0, 1.0 };
GLfloat light1_position[] = { 0.0, 4.5, 0.0, 1.0 };
GLfloat light1_direction[] = { 0.0, -1.0, 0.0, 1.0};
GLfloat light1_cutoff = 90;

float eye[] = {9.5,3,0};
float viewpt[] = {0.0,2.0,0.0};
float up[] = {0.0,1.0,0.0};
GLuint phongShade;
GLuint textureShade;
GLuint normalShade;

void view_volume() {
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0,((float)(XRES))/((float)(YRES)),0.1,20.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(eye[0],eye[1],eye[2],viewpt[0],viewpt[1],viewpt[2],up[0],up[1],up[2]);
}

// -1: teapot
void set_material(int i) {
    if (i == -1) {
        float mat_diffuse[] = {0.675,0.675,0.750,1.0}; 
        float mat_specular[] = {0.675,0.675,0.650,1.0};
        float mat_shininess[] = {60.0}; 

        glMaterialfv(GL_FRONT,GL_DIFFUSE,mat_diffuse);
        glMaterialfv(GL_FRONT,GL_SPECULAR,mat_specular);
        glMaterialfv(GL_FRONT,GL_SHININESS,mat_shininess);
        return;
    }

    glMaterialfv(GL_FRONT,GL_DIFFUSE,box[i].diffuse);
    glMaterialfv(GL_FRONT,GL_SPECULAR,box[i].specular);
    glMaterialfv(GL_FRONT,GL_SHININESS,box[i].shininess);
}

// set up lights
// light1: overall room light
// light2: aimed light
void set_light() {
    glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER,1);
    glLightfv(GL_LIGHT0,GL_DIFFUSE,light0_diffuse);
    glLightfv(GL_LIGHT0,GL_SPECULAR,light0_specular);
    glLightfv(GL_LIGHT0,GL_POSITION,light0_position);

    glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER,2);
    glLightfv(GL_LIGHT1,GL_DIFFUSE,light1_diffuse);
    glLightfv(GL_LIGHT1,GL_SPECULAR,light1_specular);
    glLightf(GL_LIGHT1,GL_SPOT_CUTOFF,light1_cutoff);
    glLightfv(GL_LIGHT1,GL_SPOT_DIRECTION,light1_direction);
    glLightfv(GL_LIGHT1,GL_SPECULAR,light1_specular);
    glLightf(GL_LIGHT1,GL_CONSTANT_ATTENUATION,1.0);
    glLightf(GL_LIGHT1,GL_LINEAR_ATTENUATION,2.0);
    glLightf(GL_LIGHT1,GL_QUADRATIC_ATTENUATION,1);
    glLightfv(GL_LIGHT1,GL_POSITION,light1_position);
} 

void drawTeapot(int y) {
    int v, t, n;

    set_material(-1);

    glBegin(GL_QUADS);
    int i;
    int f;
    for (f = 0; f < face; f++) {
        for (i = 0; i < 4; i++) {
            v = faceVec[f][i] - 1;
            t = faceTex[f][i] - 1;
            n = faceNorm[f][i] - 1;
            
            glNormal3f(normals[n].x,normals[n].y*y,normals[n].z);
            glTexCoord2f(textures[t].x, textures[t].y);
            glVertex3f(vectors[v].x,vectors[v].y*y,vectors[v].z);
        }
    }
    glEnd();

}

void draw_stuff(int m) {
Point3 edge1;
Point3 edge2;
Point2 deltaUV1;
Point2 deltaUV2;
Point3 tangent1;
Point3 bitangent1;
    int i;
    int f;

    drawTeapot(1);
    for (f = 0; f < 5; f++) { 
        if (f == 0 || f == 1) {
            glUseProgram(normalShade);
            edge1 = vecSub(box[f].quad[1],box[f].quad[0]);
            edge2 = vecSub(box[f].quad[2],box[f].quad[0]);
            deltaUV1.x = box[f].texture[1].x - box[f].texture[0].x;
            deltaUV1.y = box[f].texture[1].y - box[f].texture[0].y;
            deltaUV2.x = box[f].texture[2].x - box[f].texture[0].x;
            deltaUV2.y = box[f].texture[2].y - box[f].texture[0].y;
            GLfloat f = 1.0f / (deltaUV1.x * deltaUV2.y - deltaUV2.x * deltaUV1.y);
            tangent1.x = f * (deltaUV2.y * edge1.x - deltaUV1.y * edge2.x);
            tangent1.y = f * (deltaUV2.y * edge1.y - deltaUV1.y * edge2.y);
            tangent1.z = f * (deltaUV2.y * edge1.z - deltaUV1.y * edge2.z);
            tangent1.x = -1.0;
            tangent1.y = -1.0;
            tangent1.z = -1.0;
            tangent1 = normalize(tangent1);

            bitangent1.x = f * (-deltaUV2.x * edge1.x + deltaUV1.x * edge2.x);
            bitangent1.y = f * (-deltaUV2.x * edge1.y + deltaUV1.x * edge2.y);
            bitangent1.z = f * (-deltaUV2.x * edge1.z + deltaUV1.x * edge2.z);
            bitangent1 = normalize(bitangent1);
            GLuint indexTangent = glGetAttribLocation(normalShade, "tangent");
            GLuint indexBitangent = glGetAttribLocation(normalShade, "bitangent");
            glVertexAttrib3f(indexTangent, tangent1);
            glVertexAttrib3f(indexBitangent, bitangent1);

            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D,2);
        }
        if (f == 4) {
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D,1);
            glUseProgram(textureShade);
        }
        set_material(f);
        glBegin(GL_QUADS); 
        glNormal3f(box[f].normal.x,box[f].normal.y,box[f].normal.z);
        for(i=0;i<4;i++) {
            glTexCoord2f(box[f].texture[i].x, box[f].texture[i].y);
            glVertex3f(box[f].quad[i].x,box[f].quad[i].y,box[f].quad[i].z);
        }
        glEnd();
        glUseProgram(phongShade);
    }

    //glutSwapBuffers();
}

int rayBoxIntersect(Point3 rayDir) {
    Point3 rayPos = {light0_position[0], light0_position[1], light0_position[2]};
    Point3 norm;
    Point3 point;
    Point3 hit;
    float angle; 
    float distance;

    int i;
    for (i = 0; i < 5; i++) {
        norm = box[i].normal;
        point = box[i].quad[0];

        angle = dot(rayDir, norm);
        if (angle == 0) continue;
        distance = (dot(norm, point) - dot(norm, rayPos)) / angle;
        if (distance < 0) continue;

        hit = vecAdd(rayPos, vecScale(rayDir, distance));

        Point3 min = point;
        Point3 max = point;
        int f;
        for (f = 1; f < 4; f++) {
            if (min.x > box[i].quad[f].x)
                min.x = box[i].quad[f].x;
            if (min.y > box[i].quad[f].y)
                min.y = box[i].quad[f].y;
            if (min.z > box[i].quad[f].z)
                min.z = box[i].quad[f].z;
            if (max.x < box[i].quad[f].x)
                max.x = box[i].quad[f].x;
            if (max.y < box[i].quad[f].y)
                max.y = box[i].quad[f].y;
            if (max.z < box[i].quad[f].z)
                max.z = box[i].quad[f].z;
        }

        if (!(hit.x >= min.x && hit.x <= max.x)) continue;
        if (!(hit.y >= min.y && hit.y <= max.y)) continue;
        if (!(hit.z >= min.z && hit.z <= max.z)) continue;

        light1_position[0] = hit.x;
        light1_position[1] = hit.y;
        light1_position[2] = hit.z;

        light1_diffuse[0] = box[i].diffuse[0];
        light1_diffuse[1] = box[i].diffuse[1];
        light1_diffuse[2] = box[i].diffuse[2];

        light1_specular[0] = box[i].specular[0];
        light1_specular[1] = box[i].specular[1];
        light1_specular[2] = box[i].specular[2];

        return 1;
    }

    return 0;
}

// renderscene with accumulation
void renderScene() {
    glClearColor(0.35,0.35,0.35,1.0);
    glClearAccum(0.0,0.0,0.0,0.0);
    glClear(GL_ACCUM_BUFFER_BIT);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

// set lighting
light0_diffuse[0] = 0.0; 
light0_diffuse[1] = 0.0; 
light0_diffuse[2] = 0.0; 
light0_specular[0] = 0.0;
light0_specular[1] = 0.0;
light0_specular[2] = 0.0;
light0_position[0] = 1.0;
light0_position[1] = 4.5;
light0_position[2] = 0.0;
light0_direction[0] = 0.0;
light0_direction[1] = -1;
light0_direction[2] = 0.0;

light1_direction[0] = 0.0;
light1_direction[1] = -1.0;
light1_direction[2] = 0.0;
light1_cutoff = 90;

    Point2 lightPos;
    Point3 lightDir;

    // global illumination
    int i;
    int passes = 10000;
    for (i = 0; i < passes; i++) {
        //usleep(100000);
        printf("%d\n",i);
        Point2 lightPos = hammersley2d(i, passes);
        Point3 lightDir = hemisphereSample(lightPos.x, lightPos.y);
        lightDir.y *= -1;

        if (!rayBoxIntersect(lightDir)) 
            continue;
        set_light();
        draw_stuff(0);
        glAccum(GL_ACCUM,58/(float)passes);        
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    }

    // Ceiling Light
    int x;
    int y;
    float size = .8;
    float count = 10; // 10
    float startX = light0_position[0] - (size/2);
    float startY = light0_position[2] - (size/2);
    float posX;
    float posY;
    light1_diffuse[0] = 1.0;
    light1_diffuse[1] = 1.0;
    light1_diffuse[2] = 1.0;
    light1_specular[0] = 1.0;
    light1_specular[1] = 1.0;
    light1_specular[2] = 1.0;
    light1_direction[0] = 0;
    light1_direction[1] = 1;
    light1_direction[2] = 0;
    light1_position[1] = 4.5;
    light1_cutoff = 20;
    for (y = 0; y < count; y++) {
        for (x = 0; x < count; x++) {
            //usleep(100000);
            light1_position[0] = startX + x * (size/(count-1));
            light1_position[2]  = startY + y * (size/(count-1));
            
            set_light();
            draw_stuff(0);
            glAccum(GL_ACCUM,5/(float)1);        
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        }
    }

    // Fill Light
    //usleep(100000);
    light0_diffuse[0] = 1.0;
    light0_diffuse[1] = 1.0;
    light0_diffuse[2] = 1.0;
    light0_specular[0] = 1.0;
    light0_specular[1] = 1.0;
    light0_specular[2] = 1.0;
    set_light();
    
    //usleep(100000);
    draw_stuff(0);
    glAccum(GL_ACCUM,3/(float)4);        

    // Reflection
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    //usleep(100000);
    drawTeapot(1);
    drawTeapot(-1);
    //glutSwapBuffers();
    glAccum(GL_ACCUM,1/(float)15);        

    //usleep(100000);
    glAccum(GL_RETURN,1.0);
    glutSwapBuffers();
}

void getout(unsigned char key, int x, int y) {
    switch(key) {
        case 'q':
            exit(1);
        default:
            break;
    }
}

int main(int argc, char **argv) {
    glutInit(&argc,argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_DEPTH | GLUT_RGBA | GLUT_ACCUM | GLUT_MULTISAMPLE);
    glutInitWindowPosition(100, 100);
    glutInitWindowSize(XRES,YRES);
    glutCreateWindow("Teapot");
    load_texture("wood.ppm", 1);
    load_texture("normal_map.ppm", 2);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_MULTISAMPLE_ARB);
    view_volume();
    set_light();
    phongShade = set_shaders(0);
    textureShade = set_shaders(1);
    normalShade = set_shaders(2);
    glUseProgram(phongShade);
    loadTeapot();
    glutDisplayFunc(renderScene);
    glutKeyboardFunc(getout);
    glutMainLoop();
    return 0;
}

