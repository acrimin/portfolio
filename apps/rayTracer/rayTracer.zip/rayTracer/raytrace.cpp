/*
 * Andrew Criminski
 * contains all the functions needed set the image data
*/


#include "ray.h"

/** genRay **/
myvector genRay(scene_t *scene, int column, int row) {
   double x;
   double y;
   double z;

   myvector dir;              // Directior vector
   window_t *window;
   image_t *picture;
   window = scene->getWindow();
   picture = scene->getPicture();

   /* Computer the pixel's real scene coordinates */
   x = ((double)(column)/
      (double)(picture->columns-1))*window->getWindowWidth();
   x -= window->getWindowWidth()/2.0;
   
   y = ((double)(row)/
      (double)(picture->rows-1))*window->getWindowHeight();
   y -= window->getWindowHeight()/2.0;
   
   z = 0;

   dir = myvector(x, y, z);
   /* And now construct a unit vector from the view point to the pixel */
   dir = dir.diff(window->getViewPoint());
   dir = dir.unitvec();
   return dir;
} /* End genRay */

/** rayTrace **/
myvector rayTrace(scene_t *scene, myvector base, myvector unitDir, double total_dist, entity_t *self) {
   double x;
   double y;
   double z;
   hitinfo_t newHit;
   myvector intensity (0.0,0.0,0.0);
   mycolor  closeColor(0.0, 0.0, 0.0);
   myvector  ambient(0.0,0.0,0.0);
   myvector reflective(0.0,0.0,0.0);
   myvector r_dir(0.0,0.0,0.0);
   myvector backUnitDir=unitDir.scale(-1);
   myvector normalClose(0.0,0.0,0.0);
   myvector r_intensity(0.0,0.0,0.0);
   myvector hitpointClose(0.0,0.0,0.0);
   window_t *win;
   sobj_t *close = (sobj_t *)closest(scene, base, unitDir, self, newHit);
   
   if(close == NULL)
   {
      return myvector(0,0,0);
   }
   
   total_dist += newHit.getdistance();
   win = (window_t *)scene->getWindow();
   
   ambient = win->getAmbient();
   closeColor = close->getcolor();
   
   x = closeColor.getR() * ambient.getx();
   y = closeColor.getG() * ambient.gety();
   z = closeColor.getB() * ambient.getz();

   intensity = myvector(x, y, z);
   
   intensity=lighting(scene,close,newHit)+intensity;

   intensity = intensity.scale(1.0/255.0);
   intensity = intensity.scale(1.0/total_dist);
   
   reflective=close->getreflective();
   
   if (reflective.getx()!=0 || reflective.gety()!=0 || reflective.getz()!=0) {
      normalClose=newHit.getnormal();
      normalClose=normalClose.unitvec();
      hitpointClose=newHit.gethitpoint();
      
      r_dir=(normalClose.scale(2*(backUnitDir.dot(normalClose))))-backUnitDir;

      r_intensity=rayTrace(scene,hitpointClose,r_dir,total_dist,close);
      
      x = r_intensity.getx() * reflective.getx();
      y = r_intensity.gety() * reflective.gety();
      z = r_intensity.getz() * reflective.getz();
      
      r_intensity = myvector(x, y, z);
      intensity=intensity + r_intensity;
   }
   
   return intensity;
} /* End rayTrace */

entity_t *closest(scene_t *scene, myvector base, 
            myvector unitDir, entity_t *self, hitinfo_t &hit) {
   
   entity_t *obj;
   entity_t *close = NULL;
   iterator_t *objiter; 
   objiter = newIterator(scene->sobjList);
   hitinfo_t currhit;

   double mindist = 999999;
   int isHit;
   
   while((obj = (entity_t *)l_next(objiter)) != NULL)
   {
       isHit = obj->hits(base,unitDir,currhit);
       if(isHit && obj!=self)
       {
           if(currhit.getdistance() < mindist)
           {
               close = obj;
               mindist = currhit.getdistance();
	       hit.setdistance(currhit.getdistance());
               hit.sethitpoint(currhit.gethitpoint());
               hit.setnormal(currhit.getnormal());
           }
       }
   }
   free(objiter);
   return(close);
} /* End closest */

