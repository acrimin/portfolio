/**
    CPSC 2100
    pointlight.cpp
    Andrew Criminski
    pointlight.cpp contains all of the functions included in the pointlight class,
    which is a light found at a singular point.
**/


#include "pointlight.h"

using namespace std;

pointlight_t::pointlight_t(ifstream &infile) : entity_t(infile, "pointlight")
{
    center = myvector();
    color = mycolor();
   
    load(infile);
}

/* load takes in a file and reads in the values of the provided attribute. */
void pointlight_t::load(ifstream &infile)
{
   string token;
   infile >> token;

   while(token != ";")
   {
      if (token == "color") {
         infile >> color;
      }
      else if(token == "brightness")
      {
         infile >> brightness;
      }
      else if (token == "center") {
         infile >> center;
      }
      else 
      {
         cerr << "bad pointlight token " << token 
              << ". exiting" << endl;
         exit(1);
      }
      infile >> token;
   }

}

myvector pointlight_t::getcenter()
{
   return center;   
}


mycolor pointlight_t::getcolor()
{
   return color;
}


double pointlight_t::getbrightness()
{
   return brightness;        
}


void pointlight_t::dump()
{
   entity_t::dump();
   cerr << "color: " << color << endl;
   cerr << "brightness: " << brightness << endl;
   cerr << "center: " << center << endl;   
}


myvector pointlight_t::processLight(scene_t *scene, entity_t *ent, hitinfo_t &hit) 
{
   myvector result;
   hitinfo_t lightHit;
   double x;
   double y;
   double z;
   sobj_t *obj=NULL;
   myvector ray=hit.gethitpoint()-center;   
   double cosine=(ray.unitvec().scale(-1).dot(hit.getnormal().unitvec()));
   
   if (ent!=closest(scene,center,ray.unitvec(),NULL,lightHit))
      return (myvector){0,0,0};
   if (cosine<0)
      return (myvector){0,0,0};
   
   obj=(sobj_t*)ent;
  
   x=color.getR()*brightness*obj->getdiffuse().getx();
   y=color.getG()*brightness*obj->getdiffuse().gety();
   z=color.getB()*brightness*obj->getdiffuse().getz();
   
   result=myvector(x,y,z);
   
   result=result.scale(cosine/lightHit.getdistance());
      
   return result;
}
