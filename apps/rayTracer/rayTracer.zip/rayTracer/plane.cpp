/** 
   CpSc 2100
   Andrew Criminski
   this program initializes a new plane and contains the hits function to 
   determine plane hits
**/

#include "plane.h"
#include "hitinfo.h"

using namespace std;

// Constructor
plane_t:: plane_t(ifstream &infile) : sobj_t(infile, "plane")
{
   point = myvector();  // initalize point to <0,0,0>
   normal = myvector(); // initalize normal to <0,0,0>

   load(infile);
   normal = orient1.cross(orient2);
}

void plane_t:: load(ifstream &infile)
{
   string token;
   infile >> token;

   while(token != ";")
   {
      if (token == "orient1") {
         infile >> orient1;
      }
      else if(token == "orient2")
      {
         infile >> orient2;
      }
      else if (token == "point") {
         infile >> point;
      }
      else 
      {
         cerr << "bad plane token " << token 
              << ". exiting" << endl;
         exit(1);
      }
      infile >> token;
   }
}

myvector plane_t:: getpoint() {
   return(point);
}

myvector plane_t:: getnormal() {   
   return(normal);
}
 
int plane_t:: hits(myvector &base, myvector &dir, hitinfo_t &hit) {
   double distance;
   myvector hitPoint(0.0,0.0,0.0);
   myvector hitnormal(0.0,0.0,0.0);
  
/* Solve for distance to hit */
   distance=(normal.dot(point)-normal.dot(base))/normal.dot(dir);
   
/* Solve for hitPoint */
   hitPoint=base.sum(dir.scale(distance));
   
/* Exit if ray does not hit */
   if (normal.dot(dir)==0 || distance<0 || hitPoint.getz()>0)
      return(0);
   
   hitnormal=normal.unitvec();
   if (hitnormal.dot(dir)>0)
       hitnormal=hitnormal.scale(-1);
   
   
/* Map hitinfo */
   hit.setdistance(distance);
   hit.setnormal(hitnormal);
   hit.sethitpoint(hitPoint);
   
   return(1); 

}

void plane_t:: dump() {
   sobj_t::dump();
   cerr << "   point:         " << point << endl;
   cerr << "   normal: " << normal << endl;
} /* End dump plane */