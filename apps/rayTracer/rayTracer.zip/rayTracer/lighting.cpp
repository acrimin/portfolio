/** 
   CPSC 2100
   lighting.cpp   
   Andrew Criminski
   this file runs through all the lights to find the total ammount of light 
   on an object
**/

#include "lighting.h"


myvector lighting(scene_t *scene, entity_t *ent, hitinfo_t &hit) 
{
   myvector illumination=myvector();

   iterator_t *lightIter=NULL;
   lightIter=newIterator(scene->lightList);
   
   pointlight_t *light=NULL;
   
   while ((light =(pointlight_t*)l_next(lightIter)) != NULL) {
      illumination=light->processLight(scene,ent,hit)+illumination;
   }
   
   free(lightIter);
   return illumination;
}

