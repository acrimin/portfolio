/** CpSc 2100
   Andrew Criminski
    The sphere_t class is derived from the sobj_t class.
**/

#include "sphere.h"
#include "math.h"

using namespace std;

// Constructor
sphere_t:: sphere_t(ifstream &infile) : sobj_t(infile, "sphere")
{
   center = myvector(); // initalize normal to <0,0,0>

   load(infile);
}

void sphere_t:: load(ifstream &infile) 
{
   string token;

   infile >> token;
   while(token != ";")
   {
      if (token == "center") {
         infile >> center;
      }
      else
      if (token == "radius") {
         infile >> radius;
      }
      else 
      {
         cerr << "Unknown sphere attribute " << token << "exiting." 
              << endl;
         exit(1);
      }
      infile >> token;
   }
}

myvector sphere_t:: getcenter() {
   return center;
}

double sphere_t:: getradius() {
   return radius;
}

int sphere_t:: hits(myvector &base, myvector &dir, hitinfo_t &hit) {
   double distance;
   myvector hitPoint;
   double a;
   double b;
   double c;
   double discrim;
   myvector normal;
   
   /* move center to orgin */
   myvector orgin_base=base-center;

   /* Calculate if hit */
   a=dir.dot(dir);
   b=2*orgin_base.dot(dir);
   c=orgin_base.dot(orgin_base)-(radius*radius);   
   
   discrim=((b*b)-(4*a*c));
   
   /* Return 0 if ray is tangent or misses the sphere */
   if (discrim<=0) 
      return 0;

   /* Calculate the distance to the hitpoint */   
   distance=(-b-sqrt(discrim))/(2*a);

   /* Return 0 if the distance is negative */
   if (distance<0) 
      return 0;
      
   /* Find hitPoint */
   hitPoint=base.sum(dir.scale(distance));
   
   /* Return 0 if hitpoint z coordinate is negative */
   if (hitPoint.getz()>0) {
      return 0;
   }
   
   /* Find unit normal */
   normal=(hitPoint-center).scale(1/(hitPoint-center).length());
   

   /* Map info */
   hit.setdistance(distance);
   hit.setnormal(normal);
   hit.sethitpoint(hitPoint);
  
   return 1;
}

void sphere_t:: dump() {
   sobj_t::dump();
   cerr << "   center: " << center << endl;
   cerr << "   radius: " << radius << endl;
}