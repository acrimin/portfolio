/* 
Java Chip Software Development Group
Partners:	Drew Criminski
			Jamie Moore
*/

package javaChipGame;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

/**
 * manages players piece during gameplay
 */
public class Piece {
	private JLabel mPiece = null;
	private final Player mPlayer;
        private boolean king;
        private final int mPlayerTurn;
        private boolean alive = true;
        private int mX;
        private int mY;        

    /**
     *
     * @param icon icon object
     * @param center dimensions for center of the tile
     * @param player player object
     */
    public Piece(ImageIcon icon, int center, Player player) {
		// TODO Auto-generated constructor stub
		mPiece = new JLabel(icon, center);
		mPlayer = player;
                mPlayerTurn = player.getPlayer();
                king = false;
	}
	/**
	 * @return piece reference
	 */
	public JLabel getJLabel() {
		return mPiece;
	}
        /**
         * updates location of piece
         * @param X coordinates
         * @param Y coordinate
         */
        public void updateLocation(int X, int Y) {
            mX = X;
            mY = Y;
        }
	/**
	 * @return current player piece
	 */
	public int getPlayer() {
		return mPlayerTurn;
	}
        /**
         * removes piece from gameboard
         */
        public void removePiece() {
        	mPlayer.dockPlayer();
            alive = false;
        }
        /**
         * changes icon for the piece image to a king image
         */
        public void makeKing() {
                this.getJLabel().setIcon(new ImageIcon(this.getClass().getResource("/images/" + mPlayer.getPieceName() + " King.png")));
            	Checkers.textBox.printText("GAME: " + mPlayer.getName() + "'s Piece Was Just King'ed!!");
        	king = true;
        }
        
        /**
         * @return if piece is suppose to be king'ed or not
         */
        public boolean isKing() {
            return king;
        }
        
        /**
         * @param board Gameboard
         * @return turn if a piece can jump
         */
        public boolean canJump(GameBoard board) {
            if (!alive) {
                return false;
            }
            Square checkerBoard[][] = board.getSquareBoard();
            if (king || mPlayerTurn == 1) { // move forward
                if ((mY-2 >= 0) && (mX-2 >= 0)) {
                    if (checkerBoard[mY-2][mX-2].getCheckerPiece() == null) {
                        if ((checkerBoard[mY-1][mX-1].getCheckerPiece() != null) && (checkerBoard[mY-1][mX-1].getCheckerPiece().getPlayer() != mPlayerTurn)) {
                            return true;
                        }
                    }
                }
                if ((mY-2 >= 0) && (mX+2 < 8)) {
                    if (checkerBoard[mY-2][mX+2].getCheckerPiece() == null) {
                        if ((checkerBoard[mY-1][mX+1].getCheckerPiece() != null) && (checkerBoard[mY-1][mX+1].getCheckerPiece().getPlayer() != mPlayerTurn)) {                            
                            return true;
                        }
                    }
                }
            }
            if (king || mPlayerTurn == 2) { // move backward
                if ((mY+2 < 8) && (mX-2 >= 0)) {
                    if (checkerBoard[mY+2][mX-2].getCheckerPiece() == null) {
                        if ((checkerBoard[mY+1][mX-1].getCheckerPiece() != null) && (checkerBoard[mY+1][mX-1].getCheckerPiece().getPlayer() != mPlayerTurn)) {
                            return true;
                        }
                    }
                }
                if ((mY+2 < 8) && (mX+2 < 8)) {
                    if (checkerBoard[mY+2][mX+2].getCheckerPiece() == null) {
                        if ((checkerBoard[mY+1][mX+1].getCheckerPiece() != null) && (checkerBoard[mY+1][mX+1].getCheckerPiece().getPlayer() != mPlayerTurn)) {
                            return true;
                        }
                    }
                }
            }
            return false;
        }
        
        /**
         * @return true if a player is alive in the game
         */
        public boolean isAlive() {
            return alive;
        }
        
        /**
         * @param board Gameboard
         * @return true if a player can move in the game
         */
        public boolean canMove(GameBoard board) {
            Square checkerBoard[][] = board.getSquareBoard();
            if (king || mPlayerTurn == 1) { // move forward
                if ((mY-1 >= 0) && (mX-1 >= 0)) {
                    if (checkerBoard[mY-1][mX-1].getCheckerPiece() == null)
                        return true;
                }
                if ((mY-1 >= 0) && (mX+1 < 8)) {
                    if (checkerBoard[mY-1][mX+1].getCheckerPiece() == null)
                        return true;
                }
            }
            if (king || mPlayerTurn == 2) { // move backward
                if ((mY+1 < 8) && (mX-1 >= 0)) {
                    if (checkerBoard[mY+1][mX-1].getCheckerPiece() == null)
                        return true;
                }
                if ((mY+1 < 8) && (mX+1 < 8)) {
                    if (checkerBoard[mY+1][mX+1].getCheckerPiece() == null)
                        return true;
                }
            }
            return false;
        }

}
