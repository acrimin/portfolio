/* 
Java Chip Software Development Group
Partners:	Drew Criminski
			Jamie Moore
*/

package javaChipGame;

import java.awt.*;

import javax.swing.*;

/**
 * creates a gameboard that matches checkerboard rules.
 * Adds 12 pieces for each player.
 * Keeps track of player movements and determines their legality. 
 */
public class GameBoard {

    // GUI INFO
    private static final int HORIZONTAL = 8;
    private static final int VERTICAL = 8; 
    private static final Color LIGHT_COLOR = new Color(255, 255, 255);
    static Color DARK_COLOR;
    private static final int SQR_WIDTH = 80;
    public static final int PIECE_WIDTH = 60;
    private static final Dimension SQR_SIZE = new Dimension(SQR_WIDTH, SQR_WIDTH);

    // Class Variables
    private final JLayeredPane mainLayeredPane;
    private final JPanel board;
    private final Square[][] GameBoard;
    private final Player[] mPlayers;
    private boolean didJump;

    /**
     * draws the actual gameboard and pieces to the pane
     * @param players player objects
     */
    public GameBoard(Player players[]) {    
        mainLayeredPane = new JLayeredPane();
        board = new JPanel(new GridLayout(HORIZONTAL, VERTICAL));
        GameBoard = new Square[HORIZONTAL][VERTICAL];       
        
        mPlayers = players;
        for (int y = 0; y < VERTICAL; y++) {
            for (int x = 0; x < HORIZONTAL; x++) {
                Color bkgd = DARK_COLOR;
                if (x % 2 == y % 2) {
                    bkgd = LIGHT_COLOR;
                } 
                GameBoard[y][x] = new Square(x, y, bkgd);
                GameBoard[y][x].setPreferredSize(SQR_SIZE);
                board.add(GameBoard[y][x]);
            }
        }
        board.setSize(board.getPreferredSize());
        board.setLocation(0, 0);
        mainLayeredPane.add(board, JLayeredPane.DEFAULT_LAYER);
        mainLayeredPane.setPreferredSize(board.getPreferredSize());

        addPieces(players);
    }
    
    /**
     * creates the pieces objects for each player & adds them to the gameboard
     * @param players player objects
     */ 
    private void addPieces(Player[] players) {  
        GameBoard[5][0].add(players[0].getPiece(0));
        GameBoard[5][2].add(players[0].getPiece(1));
        GameBoard[5][4].add(players[0].getPiece(2));
        GameBoard[5][6].add(players[0].getPiece(3));
        GameBoard[6][1].add(players[0].getPiece(4));
        GameBoard[6][3].add(players[0].getPiece(5));
        GameBoard[6][5].add(players[0].getPiece(6));
        GameBoard[6][7].add(players[0].getPiece(7));
        GameBoard[7][0].add(players[0].getPiece(8));
        GameBoard[7][2].add(players[0].getPiece(9));
        GameBoard[7][4].add(players[0].getPiece(10));
        GameBoard[7][6].add(players[0].getPiece(11));
    	
    	GameBoard[0][1].add(players[1].getPiece(0));
        GameBoard[0][3].add(players[1].getPiece(1));
        GameBoard[0][5].add(players[1].getPiece(2));
        GameBoard[0][7].add(players[1].getPiece(3));
        GameBoard[1][0].add(players[1].getPiece(4));
        GameBoard[1][2].add(players[1].getPiece(5));
        GameBoard[1][4].add(players[1].getPiece(6));
        GameBoard[1][6].add(players[1].getPiece(7));
        GameBoard[2][1].add(players[1].getPiece(8));
        GameBoard[2][3].add(players[1].getPiece(9));
        GameBoard[2][5].add(players[1].getPiece(10));
        GameBoard[2][7].add(players[1].getPiece(11));
        
        Piece tempCheck;
        for (int y = 0; y < 8; y++) {
            for (int x = 0; x < 8; x++) {
                tempCheck = GameBoard[y][x].getCheckerPiece();
                if (tempCheck != null) {
                    tempCheck.updateLocation(x, y);
                }
            }
        }
    }
    
    /**
     * @return mainLayeredPane mainLayeredPane
     */
    public JComponent getMainComponent() {
        return mainLayeredPane;
    }
    
    /**
     * @return board Board
     */
    public JPanel getBoard() {
        return board;
    }
    
    /**
     * @return GameBoard Gameboard
     */
    public Square[][] getSquareBoard() {
        return GameBoard;
    }
    
    /**
     * determines if a square that a piece is being moved to is open.
     * @param oldSqr old square location
     * @param newSqr new square location
     * @param piece piece object
     * @return if new square is available
     */
    public boolean makeMove(Square oldSqr, Square newSqr, Piece piece) {
        if (newSqr == null || !validMove(oldSqr, newSqr, piece)) {
            GameBoard[oldSqr.getSqrY()][oldSqr.getSqrX()].add(piece);
            return false;
        } else {
            GameBoard[newSqr.getSqrY()][newSqr.getSqrX()].add(piece);
            piece.updateLocation(newSqr.getSqrX(), newSqr.getSqrY());
            if ((piece.getPlayer() == 1 && newSqr.getSqrY() == 0) || (piece.getPlayer() == 2 && newSqr.getSqrY() == 7)) {
                piece.makeKing();
            }
            
            if (didJump) {
                if (mPlayers[piece.getPlayer()-1].canJump(this)) {
                    Checkers.textBox.printText("GAME: You Can Jump Again!! It's Your Turn Again!");
                    didJump = false;
                    return false;
                }
            }
            
            return true;
        }
    }
    
    /**
     * determines if moves are valid. Return false if move is illegal.      
     * @param oldSqr old square location
     * @param newSqr new square location
     * @param piece piece object
     * @return true if move is valid
     */
    private boolean validMove(Square oldSqr, Square newSqr, Piece piece) {
            int X = newSqr.getSqrX();
            int Y = newSqr.getSqrY();
            int oldX = oldSqr.getSqrX();
            int oldY = oldSqr.getSqrY();
            didJump = false;
            
            if ((X % 2 == Y % 2)) {
            	Checkers.textBox.printText("GAME: Must Place Checker on Non-White Space!");
            	return false;
            }
            
            if (newSqr.getCheckerPiece() != null) {
            	Checkers.textBox.printText("GAME: Tile Already Contains a Checker!");
            	return false;
            }
            
            if (oldSqr == newSqr) {
            	Checkers.textBox.printText("GAME: Please Move The Checker Piece to a Different Space");
            	return false;
            }      
            
            boolean playerCanJump = mPlayers[piece.getPlayer()-1].canJump(this);
            
            boolean jump = false;
            boolean pass = false;
            if (piece.isKing() || piece.getPlayer() == 1) { // move forward
                if (Y == (oldY - 1) && (X == (oldX + 1) || X == (oldX - 1))) {
                    pass = true;
                }
                else if (Y == (oldY - 2) && (X == (oldX + 2) || X == (oldX - 2))) {
                    jump = true;
                    pass = true;
                }
            }
            if (piece.isKing() || piece.getPlayer() == 2) { // move backward
                if (Y == (oldY + 1) && (X == (oldX + 1) || X == (oldX - 1))) {
                    pass = true;
                }
                else if (Y == (oldY + 2) && (X == (oldX + 2) || X == (oldX - 2))) {
                    jump = true;
                    pass = true;
                }
            }
            if (!pass) { // not moved 1 or 2 diagonally
                Checkers.textBox.printText("GAME: Piece Can Only Move Diagonally 1 Position (or 2 positions if jumping)!");
                return false;                
            }
            
                 
            if (jump) {
                if (GameBoard[(oldY + Y)/2][(oldX + X)/2].getCheckerPiece() == null) {
                    Checkers.textBox.printText("GAME: Piece Can Only Move Diagonally 2 Positions If Jumping Over a Piece!");
                    return false;
                }
                else if (GameBoard[(oldY + Y)/2][(oldX + X)/2].getCheckerPiece().getPlayer() == piece.getPlayer()) {
                    Checkers.textBox.printText("GAME: Piece Can Only Jump Over a Piece of the Opposing Team!");
                    return false;
                }
                else {
                    didJump = true;
                    GameBoard[(oldY + Y)/2][(oldX + X)/2].getCheckerPiece().removePiece();
                    GameBoard[(oldY + Y)/2][(oldX + X)/2].removePiece();                    
                }
            }
                        
            if (playerCanJump) {
                if  (!didJump) {
                    Checkers.textBox.printText("GAME: You Must Jump!");
                    return false;
                }
            }
            
            return true;
        }

}
