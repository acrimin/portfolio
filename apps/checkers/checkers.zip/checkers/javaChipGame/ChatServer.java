/* 
Java Chip Software Development Group
Partners:	Drew Criminski
			Jamie Moore
*/

package javaChipGame;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * controls chatting between players online
 */
class ChatServer implements Runnable {
    private String name;
    private final int port;

    ChatServer(int port) {  
        this.port = port;
    }

    @Override
    /**
     * Initiates chatting between players when playing game online
     */
    public void run() {
        try {
            ServerSocket serverSocket = new ServerSocket(port);
            Socket player = serverSocket.accept();
            ObjectOutputStream toPlayer = new ObjectOutputStream(player.getOutputStream());
            ObjectInputStream fromPlayer = new ObjectInputStream(player.getInputStream());
            name = fromPlayer.readUTF();
            Checkers.textBox.printText(name);
            while (true) {
                String read = fromPlayer.readUTF();
                toPlayer.writeUTF(read);
                Checkers.textBox.printText(name + ": "+ read);
            }
        } catch (IOException ex) {
            Logger.getLogger(ChatServer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
