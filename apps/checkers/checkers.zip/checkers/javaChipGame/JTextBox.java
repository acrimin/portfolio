/* 
Java Chip Software Development Group
Partners:	Drew Criminski
			Jamie Moore
*/

package javaChipGame;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.text.DefaultCaret;

@SuppressWarnings("serial")
/**
 * creates dialogue window objects & functions.
 */
public class JTextBox extends  JPanel implements ActionListener {	
    String input;
    JTextField textField;
    JTextArea textArea;
    ObjectInputStream fromServer;
    ObjectOutputStream toServer;

	/**
	 * creates textboxes for user interaction between each other and game.
	 */
    public JTextBox() {
        // TODO Auto-generated constructor stub
        super(new GridBagLayout());

        textField = new JTextField(45);
        textField.addActionListener(this);

        textArea = new JTextArea(10, 45);
        DefaultCaret caret = (DefaultCaret)textArea.getCaret();
        caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);

        GridBagConstraints c = new GridBagConstraints();
        c.gridwidth = GridBagConstraints.REMAINDER;

        c.fill = GridBagConstraints.BOTH;
        c.weightx = 1.0;
        c.weighty = 1.0;
        add(scrollPane, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        add(textField, c);
    }
	
    @Override
    /**
     * adds text to the dialogue box
     */
    public void actionPerformed(ActionEvent evt) {
        try {
            String text = textField.getText();
            textArea.append("Me: " + text + "\n");
            textField.selectAll();
            textField.cut();
            
            textArea.setCaretPosition(textArea.getDocument().getLength());
            
            toServer.writeUTF(text);
            toServer.flush();
        } catch (IOException ex) {
            Logger.getLogger(JTextBox.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
	
    /**
	 * @return spacer for text objects and messages
	 */
    public String getText() {
        return " ";
    }

	/**
	 * adds text to the bottom user dialogue 
	 * @param text text to be added
	 */
    public void printText(String text) {
        textArea.append(text + "\n");
    }

    /**
     * @param toServer text to be sent to Server
     */
    void setOutputStream(ObjectOutputStream toServer) {
        this.toServer = toServer;
    }
    
    /**
     * @param toServer text recieved from Server
     */
    void setInputStream(ObjectInputStream fromServer) {
        this.fromServer = fromServer;
    }

}