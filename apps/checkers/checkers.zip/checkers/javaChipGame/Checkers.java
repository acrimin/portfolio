/* 
Java Chip Software Development Group
Partners:	Drew Criminski
                Jamie Moore
*/

package javaChipGame;

import java.awt.GridLayout;
import java.io.IOException;
import javax.swing.*;

/**
 * Establishes the game as either online or offline
 */
public class Checkers {
    public static JTextBox textBox;
    public static int gameMode;

    /**
     * opens dialogue box and starts new game while initiates networking
     * @param args command line inputs
     * @throws IOException online connection exception
     * @throws InterruptedException connection interrupted
     * @throws ClassNotFoundException program not found
     */
    public static void main(String[] args) throws IOException, InterruptedException, ClassNotFoundException {
        textBox = new JTextBox();       
        
        JTextField ipInput = new JTextField(20);      
        ButtonGroup buttonGroup = new ButtonGroup();
        JRadioButton onlineButton = new JRadioButton();
        onlineButton.setText("Online");        
        JRadioButton offlineButton = new JRadioButton();
        offlineButton.setText("Offline");
        offlineButton.setSelected(true);
        buttonGroup.add(onlineButton);
        buttonGroup.add(offlineButton);
        
        JPanel myPanel = new JPanel(new GridLayout(2,1));
        
        myPanel.add(new JLabel("Leave HostIP BLANK if Player is Host"));
        JPanel subPanel = new JPanel(new GridLayout(2,2));
        
        subPanel.add(onlineButton);
        subPanel.add(ipInput);        
        subPanel.add(offlineButton);
        myPanel.add(subPanel);
              
        JOptionPane.showConfirmDialog(null, myPanel, 
                 "Game Type", JOptionPane.DEFAULT_OPTION);       
           
        if (onlineButton.isSelected()) {
            String host = ipInput.getText();
            new OnlineGameClient(host);
        } else {        
            new Game();
        }
    }
}

