/* 
Java Chip Software Development Group
Partners:	Drew Criminski
			Jamie Moore
*/

package javaChipGame;

import java.awt.*;
import javax.swing.*;

@SuppressWarnings("serial")
/**
 * creates game tile images
 */
public class Square extends JPanel {
    private final int mX;
    private final int mY;
    private Piece checkerPiece = null;

    /** 
     * setups where white squares will be within the game
     * @param X coordinate
     * @param Y coordinate
     * @param bkgrnd color background
     */
    public Square(int X, int Y, Color bkgrnd) {
        mX = X;
        mY = Y;
        setBackground(bkgrnd);
        setLayout(new GridBagLayout());
    }

    /**
     * @return X coordinate of square
     */
    public int getSqrX() {
        return mX;
    }
    
    /**
     * @return Y coordinate of square
     */
    public int getSqrY() {
        return mY;
    }

    /**
     * @param p piece object
     * @return adding piece to board
     */
    public Component add(Piece p) {
        checkerPiece = p;
        return super.add(p.getJLabel());
    }

    /**
     * @return checker piece object
     */
    public Piece getCheckerPiece() {
        return checkerPiece;
    }
    
    /**
     * deletes the piece from the gameboard
     */
    public void removePiece() {
    	this.removeAll();
    	this.revalidate();
    	this.repaint();
        checkerPiece = null;
    }
}
