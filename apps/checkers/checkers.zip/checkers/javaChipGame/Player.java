/* 
Java Chip Software Development Group
Partners:	Drew Criminski
                Jamie Moore
*/

package javaChipGame;

import java.net.Socket;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;

/**
 * manages player objects within the game
 */
class Player {
    private final String mPlayerName;
    private final String mPieceName;
    private final int mNumber;
    private final Piece[] mPieces;
    private int piecesRemaining;
    
    /**
     * holds variables for each game player
     * @param board Gameboard
     * @param name player name
     * @param piece piece object
     * @param number piece number
     */
    public Player(GameBoard board, String name, String piece, int number) {
        mPlayerName = name;
        mPieceName = piece;
        mNumber = number;
        piecesRemaining = 12;
        
        mPieces = new Piece[12];
        createPieces();
    }
    
    public Player(GameBoard board, String name, String piece, int number, Socket[] players) {
        mPlayerName = name;
        mPieceName = piece;
        mNumber = number;
        piecesRemaining = 12;
        
        mPieces = new Piece[12];
        createPieces();
    }   
    /**
     * @return player name
     */
    public String getName() {
        return mPlayerName;
    }
    
    /**
     * @return player number 1 or 2
     */
    public int getPlayer() {
        return mNumber;
    }
    
    /**
     * @param index
     * @return piece index
     */
    public Piece getPiece(int index) {
        return mPieces[index];
    }
    
    /**
     * @return piece name for player
     */
    public String getPieceName() {
        return mPieceName;
    }
    
    /**
     * deducts one point from players 12 pieces
     */
    public void dockPlayer() {
    	piecesRemaining--;
    }
    
    /**
     * @param board Gameboard
     * @return true if a player can jump
     */
    public boolean canJump(GameBoard board) {
        for (int i = 0; i < 12; i++) {
            if (mPieces[i] != null) {
                if (mPieces[i].canJump(board)) {
                    return true;
                }
            }
        }
        
        return false;
    }
    
    /**
     * @param board Gameboard
     * @return true if a player can jump
     */
    public boolean canMove(GameBoard board) {    
        for (int i = 0; i < 12; i++) {
            if (mPieces[i] != null && mPieces[i].isAlive()) {
                if (mPieces[i].canMove(board)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * @param board Gameboard
     * @return true if a player is alive in the game
     */
    public boolean isAlive(GameBoard board) {
        return canMove(board) || canJump(board);
    }
    
    /**
     * creates the 12 pieces needed by each game player
     */
    private void createPieces() {
        ImageIcon image = new ImageIcon(this.getClass().getResource("/images/" + mPieceName + ".png"));
        
        for (int i = 0; i < 12; i++) {
        	mPieces[i] = new Piece(image, SwingConstants.CENTER, this);
        }
    }
}
