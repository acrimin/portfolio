/* 
Java Chip Software Development Group
Partners:	Drew Criminski
			Jamie Moore
*/

package javaChipGame;

import java.awt.*;
import java.awt.image.BufferedImage;

public class PieceGUI {
	public static BufferedImage createImage(int size, Color color) {
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = img.createGraphics();
        g2.setColor(color);
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.fillOval(0,0,size,size);
        g2.dispose();
        return img;
    }
}
