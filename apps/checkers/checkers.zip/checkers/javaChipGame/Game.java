/* 
Java Chip Software Development Group
Partners:	Drew Criminski
                Jamie Moore
*/

package javaChipGame;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.Box;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * Controls standard gameplay
 */
public class Game {
        private final GameBoard board;
        private final Player[] players;
        private int gameTurn;
        /**
         * starts a new game by creating two players, drawing a board, setting player1 to go first
         */   
    public Game() {
        players = new Player[2];
        getPlayers();
        board = new GameBoard(players);
        basicGui();
        gameTurn = 1;
        MyMouseAdapter mouseAdapter = new MyMouseAdapter();
        board.getMainComponent().addMouseListener(mouseAdapter);
        board.getMainComponent().addMouseMotionListener(mouseAdapter);
    }
    /**
     * alternates whose turn it is during the game
     */
    private void toggleGameTurn() {    	
    	if (gameTurn == 1) {
            gameTurn = 2;
            if (players[1].isAlive(board))
                Checkers.textBox.printText("GAME: " + players[1].getName() + "'s Turn!");
            else
                gameOver(0);
        }    	
    	else {            
            gameTurn = 1;
            if (players[0].isAlive(board))
                Checkers.textBox.printText("GAME: " + players[0].getName() + "'s Turn!");
            else
                gameOver(1);
        }   
    }
    
    /**
     * outputs that a player has won the game by displaying a message in the dialogue window. 
     * Asks players if they want to play again.
     * @param winner which player won the game
     */
    private void gameOver(int winner) {
                Checkers.textBox.printText("GAME: " + players[winner].getName() + " has won the game!!");
        int result = JOptionPane.showConfirmDialog(null, players[winner].getName() +
                        " Has Won The Game!!\n\nDo you want to play again??","GAME WON!!!", JOptionPane.YES_NO_OPTION);
        if(result == JOptionPane.YES_OPTION) 
            new Game();
        else 
            System.exit(0); 
    }
    
    /**
     * the initial player on-boarding process where players define their name, piece image & tile colors.
     */
    private void getPlayers() {
    	String p1NameString, p2NameString, p1PieceString, p2PieceString, boxColorChoice;

        JTextField p1name = new JTextField(15);
        JTextField p2name = new JTextField(15);
        String[] pieceChoices = { "Clemson", "UofSC", "Notre Dame", "UofNC", "Florida State", "UofGA", "Ohio State" };
        String[] colorChoices = { "Black", "Blue", "Cyan", "Green", "Pink", "Orange", "Yellow" };
        
        JPanel myPanel = new JPanel(new GridLayout(0,1));
        myPanel.add(new JLabel("Player 1 Name & Piece:"));
        myPanel.add(p1name);
        JComboBox<String> p1Piece = new JComboBox<>(pieceChoices);
        myPanel.add(p1Piece);
        myPanel.add(Box.createVerticalStrut(15)); // field spacer
        myPanel.add(new JLabel("Player 2 Name & Piece:"));
        myPanel.add(p2name);
        JComboBox<String> p2Piece = new JComboBox<>(pieceChoices);
        myPanel.add(p2Piece);
        myPanel.add(Box.createVerticalStrut(25)); // field spacer
        myPanel.add(new JLabel("Preferred Color Scheme:"));
        JComboBox<String> boxColor = new JComboBox<>(colorChoices);
        myPanel.add(boxColor);

        JOptionPane.showConfirmDialog(null, myPanel, 
                 "Player Onboarding", JOptionPane.DEFAULT_OPTION);
        
        p1NameString = p1name.getText(); 
        p2NameString = p2name.getText();
        p1PieceString = p1Piece.getSelectedItem().toString();
        p2PieceString = p2Piece.getSelectedItem().toString();
         
        while (p1NameString.length() < 1 || p2NameString.length() < 1 || p1NameString.equals(p2NameString) || p1PieceString.equals(p2PieceString)) {
        	JOptionPane.showMessageDialog(myPanel, "Please input two valid player names with different piece choices!!", "Player Onboarding",
        		    JOptionPane.WARNING_MESSAGE);
        	int result = JOptionPane.showConfirmDialog(null, myPanel, 
                    	"Player Onboarding", JOptionPane.OK_CANCEL_OPTION);
           if (result == JOptionPane.CANCEL_OPTION) System.exit(0);
           
           p1NameString = p1name.getText(); 
           p2NameString = p2name.getText();
           p1PieceString = p1Piece.getSelectedItem().toString();
           p2PieceString = p2Piece.getSelectedItem().toString();
        }
    	
        boxColorChoice = boxColor.getSelectedItem().toString();
        if (boxColorChoice == "Black" ) GameBoard.DARK_COLOR = new Color(0,0,0);
        if (boxColorChoice == "Blue" ) GameBoard.DARK_COLOR = new Color(30,144,255);
        if (boxColorChoice == "Cyan" ) GameBoard.DARK_COLOR = new Color(0,255,255);
        if (boxColorChoice == "Green" ) GameBoard.DARK_COLOR = new Color(50,205,50);
        if (boxColorChoice == "Pink" ) GameBoard.DARK_COLOR = new Color(255,192,203);
        if (boxColorChoice == "Orange" ) GameBoard.DARK_COLOR = new Color(234,106,32);
        if (boxColorChoice == "Yellow" ) GameBoard.DARK_COLOR = new Color(255,255,0);
        
        Checkers.textBox.setBackground(new Color(0,0,153));
    	
    	Checkers.textBox.printText("\nWelcome " + p1NameString + " & " + p2NameString + "!!\n -------------------- \n");
    	
    	Checkers.textBox.printText("GAME: " + p1NameString + "'s Turn!");
        
        players[0] = new Player(board, p1NameString, p1PieceString, 1);
        players[1] = new Player(board, p2NameString, p2PieceString, 2);
    }

    /**
     * creates the basic interface for the checkerboard along with dialogue box
     */
	private void basicGui() {
        JFrame textFrame = new JFrame("Checkers Program Dialogue");
        textFrame.getContentPane().add(Checkers.textBox);
        textFrame.pack();
        
        JFrame frame = new JFrame("Java Chip Checkers");
        frame.getContentPane().add(board.getMainComponent());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setResizable(false);
        
        textFrame.setVisible(true);
    }
	
	/**
     * holds the variables for the movement of the mouse
     */
	private class MyMouseAdapter extends MouseAdapter {
        private Piece piece;
        private Point delta;
        private Square oldSqr;

		
        @Override
        /**
         * determines if movement of piece was legal
         */
        public void mousePressed(MouseEvent e) {
            Point p = e.getPoint();
            oldSqr = (Square) board.getBoard().getComponentAt(p);
            
            if (oldSqr.getCheckerPiece() != null && oldSqr.getCheckerPiece().getPlayer() != gameTurn) {
                Checkers.textBox.printText("GAME: Not Your Turn!");
            }            
            else if (oldSqr.getCheckerPiece() != null) {
                piece = oldSqr.getCheckerPiece();
                oldSqr.removePiece();
                board.getMainComponent().add(piece.getJLabel(), JLayeredPane.DRAG_LAYER);
                int x = p.x - GameBoard.PIECE_WIDTH/2;
                int y = p.y - GameBoard.PIECE_WIDTH/2;
                piece.getJLabel().setLocation(x, y);

                delta = new Point(p.x - x, p.y - y);

                return;
            }
            
            oldSqr = null;
        }

        @Override
        /**
         * allows the piece to be moved by the mouse realistically
         */
        public void mouseDragged(MouseEvent e) {
            if (piece != null) {
                Point p = e.getPoint();
                int x = p.x - delta.x;
                int y = p.y - delta.y;
                piece.getJLabel().setLocation(x, y);
                board.getMainComponent().revalidate();
                board.getMainComponent().repaint();
            }
        }

        @Override
        /**
         * draws the piece to the permanently to the board until it is moved again
         */
        public void mouseReleased(MouseEvent e) {
            if (piece != null) {
                Point p = e.getPoint();
                Square newSqr = (Square) board.getBoard().getComponentAt(p);
                board.getMainComponent().remove(piece.getJLabel());
                if (board.makeMove(oldSqr, newSqr, piece)) {
                    toggleGameTurn();
                }
                
                piece = null;
                delta = null;
                
                oldSqr = null;

                board.getBoard().revalidate();
                board.getMainComponent().repaint();
            }
        }
    }

    
}
