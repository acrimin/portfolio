/* 
Java Chip Software Development Group
Partners:	Drew Criminski
			Jamie Moore
*/

package javaChipGame;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Inet4Address;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * manages online game play between players
 */
public class OnlineGameServer implements Runnable {
    
    public OnlineGameServer() {
    }

    @Override
    /**
     * Initiates online game play server-side
     */
    public void run() {
        try {
            ServerSocket serverSocket = new ServerSocket(8000);
            System.out.println("Server ip: " + Inet4Address.getLocalHost().getHostAddress());

            Socket player1Socket = serverSocket.accept();
            Socket player2Socket = serverSocket.accept();            
            
            ObjectInputStream fromPlayer1 = new ObjectInputStream(player1Socket.getInputStream());
            ObjectOutputStream toPlayer1 = new ObjectOutputStream(player1Socket.getOutputStream());
            ObjectInputStream fromPlayer2 = new ObjectInputStream(player2Socket.getInputStream());
            ObjectOutputStream toPlayer2 = new ObjectOutputStream(player2Socket.getOutputStream());
                      
            String p1NameString = fromPlayer1.readUTF();
            String p1PieceString = fromPlayer1.readUTF();
            String p2NameString = fromPlayer2.readUTF();
            String p2PieceString = fromPlayer2.readUTF();                            
       
            toPlayer1.writeUTF(p2NameString);
            toPlayer1.flush();              
            toPlayer1.writeUTF(p2PieceString);
            toPlayer1.flush();                       
            toPlayer2.writeUTF(p1NameString);
            toPlayer2.flush();
            toPlayer2.writeUTF(p1PieceString);
            toPlayer2.flush();
            
            int gameTurn = 1;
            int fromX;
            int fromY;
            int toX;
            int toY;
            while (true) {
                if (gameTurn == 1) {
                    fromX = fromPlayer1.readInt();
                    fromY = fromPlayer1.readInt();
                    toX = fromPlayer1.readInt();
                    toY = fromPlayer1.readInt();
                    
                    toPlayer2.writeInt(fromX);
                    toPlayer2.flush();
                    toPlayer2.writeInt(fromY);
                    toPlayer2.flush();
                    toPlayer2.writeInt(toX);
                    toPlayer2.flush();
                    toPlayer2.writeInt(toY);
                    toPlayer2.flush();
                    
                    if (fromPlayer1.readBoolean()) 
                        gameTurn = 2;
                } else {
                    fromX = fromPlayer2.readInt();
                    fromY = fromPlayer2.readInt();
                    toX = fromPlayer2.readInt();
                    toY = fromPlayer2.readInt();
                    
                    toPlayer1.writeInt(fromX);
                    toPlayer1.flush();
                    toPlayer1.writeInt(fromY);
                    toPlayer1.flush();
                    toPlayer1.writeInt(toX);
                    toPlayer1.flush();
                    toPlayer1.writeInt(toY);
                    toPlayer1.flush();
                    
                    if (fromPlayer2.readBoolean()) 
                        gameTurn = 1;
                }
            }           
        } catch (IOException ex) {
            Logger.getLogger(OnlineGameServer.class.getName()).log(Level.SEVERE, null, ex);
        }       
    }
}
